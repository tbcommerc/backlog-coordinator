-- DBA ONLY. Existing empty PostgreSQL 16 database.
BEGIN;
-- DBA ONLY. Existing empty database; application must never execute this file.
--
-- PostgreSQL database dump
--


-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: preserve_work_relations_on_task_delete(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.preserve_work_relations_on_task_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 UPDATE request_work_links SET is_active=false WHERE major_task_id=OLD.id;
 UPDATE work_dependencies SET is_active=false, reason=reason || ' Контекст Task ' || OLD.id || ' удалён.' WHERE source_major_id=OLD.id OR target_major_id=OLD.id;
 RETURN OLD;
END $$;


--
-- Name: prevent_work_snapshot_mutation(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.prevent_work_snapshot_mutation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN RAISE EXCEPTION 'Work meeting snapshots are immutable'; END $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agent_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_sessions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    agent_session_id character varying(64) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: agent_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agent_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agent_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agent_sessions_id_seq OWNED BY public.agent_sessions.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id integer NOT NULL,
    user_id integer,
    action character varying(50) NOT NULL,
    entity_type character varying(50) NOT NULL,
    entity_id integer,
    details text,
    ip_address character varying(45),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    request_id character varying(64),
    trace_id character varying(32),
    legacy_references json
);


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: auth_challenges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_challenges (
    id character varying(36) NOT NULL,
    user_id integer NOT NULL,
    issuer_id integer,
    purpose character varying(48) NOT NULL,
    token_hash character varying(64) NOT NULL,
    auth_version bigint NOT NULL,
    session_id character varying(36),
    target_user_id integer,
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone,
    revoked_at timestamp with time zone
);


--
-- Name: auth_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_sessions (
    id character varying(36) NOT NULL,
    user_id integer NOT NULL,
    auth_version bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    last_activity_at timestamp with time zone NOT NULL,
    absolute_expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    revoke_reason character varying(64),
    ip_address character varying(64),
    client_label character varying(256)
);


--
-- Name: backlog_assistant_integration; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.backlog_assistant_integration (
    id character varying(64) NOT NULL,
    kind character varying(24) NOT NULL,
    subject character varying(64) NOT NULL,
    payload json NOT NULL,
    expires double precision NOT NULL
);


--
-- Name: business_customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.business_customers (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    department_id integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: business_customers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.business_customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: business_customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.business_customers_id_seq OWNED BY public.business_customers.id;


--
-- Name: channels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channels (
    id integer NOT NULL,
    code character varying(50) NOT NULL,
    name character varying(100) NOT NULL
);


--
-- Name: channels_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.channels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: channels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.channels_id_seq OWNED BY public.channels.id;


--
-- Name: column_labels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.column_labels (
    id integer NOT NULL,
    key character varying(50) NOT NULL,
    label character varying(200) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: column_labels_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.column_labels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: column_labels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.column_labels_id_seq OWNED BY public.column_labels.id;


--
-- Name: competency_cost_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.competency_cost_history (
    id integer NOT NULL,
    competency character varying(100) NOT NULL,
    year integer NOT NULL,
    rate double precision NOT NULL,
    is_active boolean,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: competency_cost_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.competency_cost_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: competency_cost_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.competency_cost_history_id_seq OWNED BY public.competency_cost_history.id;


--
-- Name: deadlines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deadlines (
    id integer NOT NULL,
    code character varying(50) NOT NULL,
    name character varying(100) NOT NULL
);


--
-- Name: deadlines_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.deadlines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: deadlines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.deadlines_id_seq OWNED BY public.deadlines.id;


--
-- Name: departments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.departments (
    id integer NOT NULL,
    code character varying(50) NOT NULL,
    name character varying(255) NOT NULL,
    color character varying(20),
    sort_order integer,
    is_active boolean,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    version integer,
    lock_owner_id integer,
    lock_until timestamp with time zone
);


--
-- Name: COLUMN departments.version; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.departments.version IS 'Версия справочника (optimistic lock)';


--
-- Name: departments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.departments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: departments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.departments_id_seq OWNED BY public.departments.id;


--
-- Name: dictionary_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dictionary_items (
    id integer NOT NULL,
    dict_type character varying(50) NOT NULL,
    name character varying(100) NOT NULL,
    code character varying(50),
    color character varying(20),
    sort_order integer,
    is_active boolean,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    version integer,
    lock_owner_id integer,
    lock_until timestamp with time zone,
    reference_id integer
);


--
-- Name: COLUMN dictionary_items.version; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dictionary_items.version IS 'Версия справочника (optimistic lock)';


--
-- Name: dictionary_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.dictionary_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dictionary_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.dictionary_items_id_seq OWNED BY public.dictionary_items.id;


--
-- Name: did_client_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.did_client_groups (
    id integer NOT NULL,
    code character varying(50) NOT NULL,
    name character varying(100) NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: did_client_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.did_client_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: did_client_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.did_client_groups_id_seq OWNED BY public.did_client_groups.id;


--
-- Name: display_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.display_settings (
    id integer NOT NULL,
    page character varying(50) NOT NULL,
    settings text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: display_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.display_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: display_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.display_settings_id_seq OWNED BY public.display_settings.id;


--
-- Name: effort_rub_normalization_audit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.effort_rub_normalization_audit (
    task_id integer NOT NULL,
    old_effort_rub numeric(18,2),
    old_cv double precision
);


--
-- Name: effort_rub_normalization_audit_task_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.effort_rub_normalization_audit_task_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: effort_rub_normalization_audit_task_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.effort_rub_normalization_audit_task_id_seq OWNED BY public.effort_rub_normalization_audit.task_id;


--
-- Name: epics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.epics (
    id integer NOT NULL,
    task_id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    priority character varying(50),
    effort_designee double precision,
    effort_analytics double precision,
    effort_be double precision,
    effort_python_be double precision,
    effort_fe double precision,
    effort_test double precision,
    effort_test_auto double precision,
    effort_delivery double precision,
    sort_order integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: COLUMN epics.priority; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.epics.priority IS 'Приоритет эпика';


--
-- Name: COLUMN epics.effort_designee; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.epics.effort_designee IS 'Designee (дни)';


--
-- Name: COLUMN epics.effort_analytics; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.epics.effort_analytics IS 'Аналитика (дни)';


--
-- Name: COLUMN epics.effort_be; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.epics.effort_be IS 'Разработка BE (дни)';


--
-- Name: COLUMN epics.effort_python_be; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.epics.effort_python_be IS 'Разработка python BE (дни)';


--
-- Name: COLUMN epics.effort_fe; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.epics.effort_fe IS 'Разработка FE (дни)';


--
-- Name: COLUMN epics.effort_test; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.epics.effort_test IS 'Tester (дни)';


--
-- Name: COLUMN epics.effort_test_auto; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.epics.effort_test_auto IS 'Tester Auto (дни)';


--
-- Name: COLUMN epics.effort_delivery; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.epics.effort_delivery IS 'Delivery (дни)';


--
-- Name: COLUMN epics.sort_order; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.epics.sort_order IS 'Порядок сортировки';


--
-- Name: epics_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.epics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: epics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.epics_id_seq OWNED BY public.epics.id;


--
-- Name: event_outbox; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_outbox (
    id integer NOT NULL,
    event_type character varying(100) NOT NULL,
    aggregate_type character varying(50) NOT NULL,
    aggregate_id integer,
    aggregate_version integer,
    audience_user_id integer,
    payload json NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    available_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    claimed_at timestamp with time zone,
    claim_token character varying(64),
    processed_at timestamp with time zone,
    attempts integer DEFAULT 0 NOT NULL,
    last_error text,
    dead_lettered_at timestamp with time zone
);


--
-- Name: event_outbox_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.event_outbox_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: event_outbox_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.event_outbox_id_seq OWNED BY public.event_outbox.id;


--
-- Name: field_labels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.field_labels (
    id integer NOT NULL,
    key character varying(50) NOT NULL,
    label character varying(200) NOT NULL,
    "group" character varying(50),
    sort_order integer,
    is_required boolean,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: COLUMN field_labels.label; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.field_labels.label IS 'Точное русское название поля для отображения на фронте';


--
-- Name: COLUMN field_labels."group"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.field_labels."group" IS 'Группа полей (основные/трудозатраты/статусы/прочее)';


--
-- Name: COLUMN field_labels.is_required; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.field_labels.is_required IS 'Обязательность поля при импорте задач из CSV (Обязательность = Да)';


--
-- Name: field_labels_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.field_labels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: field_labels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.field_labels_id_seq OWNED BY public.field_labels.id;


--
-- Name: idempotency_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.idempotency_records (
    id integer NOT NULL,
    operation character varying(100) NOT NULL,
    user_id integer NOT NULL,
    request_key character varying(64) NOT NULL,
    request_hash character varying(64) NOT NULL,
    resource_type character varying(50),
    resource_id integer,
    resource_version integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: idempotency_records_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.idempotency_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: idempotency_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.idempotency_records_id_seq OWNED BY public.idempotency_records.id;


--
-- Name: issue_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.issue_tags (
    id integer NOT NULL,
    issue_id integer NOT NULL,
    tag_id integer NOT NULL
);


--
-- Name: issue_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.issue_tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: issue_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.issue_tags_id_seq OWNED BY public.issue_tags.id;


--
-- Name: kr_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kr_comments (
    id integer NOT NULL,
    metric_id integer NOT NULL,
    author_id integer NOT NULL,
    text text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    period_id integer
);


--
-- Name: kr_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kr_comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kr_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kr_comments_id_seq OWNED BY public.kr_comments.id;


--
-- Name: kr_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kr_files (
    id integer NOT NULL,
    metric_id integer NOT NULL,
    measurement_id integer,
    author_id integer NOT NULL,
    filename character varying(255) NOT NULL,
    storage_key character varying(80) NOT NULL,
    size integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    period_id integer
);


--
-- Name: kr_files_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kr_files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kr_files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kr_files_id_seq OWNED BY public.kr_files.id;


--
-- Name: kr_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kr_history (
    id integer NOT NULL,
    metric_id integer NOT NULL,
    period_id integer,
    actor_id integer,
    action character varying(40) NOT NULL,
    before json DEFAULT '{}'::json NOT NULL,
    after json DEFAULT '{}'::json NOT NULL,
    reason text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: kr_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kr_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kr_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kr_history_id_seq OWNED BY public.kr_history.id;


--
-- Name: kr_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kr_links (
    id integer NOT NULL,
    metric_id integer NOT NULL,
    task_id integer,
    work_task_id integer,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_kr_link_target CHECK (((task_id IS NULL) <> (work_task_id IS NULL)))
);


--
-- Name: kr_links_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kr_links_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kr_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kr_links_id_seq OWNED BY public.kr_links.id;


--
-- Name: kr_measurements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kr_measurements (
    id integer NOT NULL,
    period_id integer NOT NULL,
    measured_on date NOT NULL,
    value numeric(30,10) NOT NULL,
    source text NOT NULL,
    comment text DEFAULT ''::text NOT NULL,
    author_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: kr_measurements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kr_measurements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kr_measurements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kr_measurements_id_seq OWNED BY public.kr_measurements.id;


--
-- Name: kr_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kr_metrics (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    team_id integer NOT NULL,
    owner_id integer,
    project_id integer,
    unit character varying(50) DEFAULT ''::character varying NOT NULL,
    method text DEFAULT ''::text NOT NULL,
    source text DEFAULT ''::text NOT NULL,
    involved_team_ids json DEFAULT '[]'::json NOT NULL,
    tags json DEFAULT '[]'::json NOT NULL,
    priority_id integer,
    business_customer_id integer,
    department_id integer,
    did_client_group_id integer,
    legacy_task_id integer,
    legacy_snapshot json,
    is_archived boolean DEFAULT false NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_by integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    model_version character varying(16) DEFAULT 'legacy_v1'::character varying NOT NULL,
    lifecycle_state character varying(16) DEFAULT 'draft'::character varying NOT NULL,
    annual_aggregation character varying(10) DEFAULT 'none'::character varying NOT NULL,
    aggregation_scale integer DEFAULT 100 NOT NULL,
    display_precision integer DEFAULT 2 NOT NULL,
    preferred_result_type character varying(16),
    default_direction character varying(10),
    CONSTRAINT ck_kr_metric_version CHECK ((version > 0))
);


--
-- Name: kr_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kr_metrics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kr_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kr_metrics_id_seq OWNED BY public.kr_metrics.id;


--
-- Name: kr_pause_intervals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kr_pause_intervals (
    id integer NOT NULL,
    metric_id integer NOT NULL,
    start_date date NOT NULL,
    end_date date,
    author_id integer NOT NULL,
    reason text NOT NULL
);


--
-- Name: kr_pause_intervals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kr_pause_intervals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kr_pause_intervals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kr_pause_intervals_id_seq OWNED BY public.kr_pause_intervals.id;


--
-- Name: kr_period_closure_revisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kr_period_closure_revisions (
    id integer NOT NULL,
    period_id integer NOT NULL,
    plan_revision_id integer NOT NULL,
    fact_revision_id integer NOT NULL,
    previous_revision_id integer,
    author_id integer NOT NULL,
    snapshot json NOT NULL,
    comment text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: kr_period_closure_revisions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kr_period_closure_revisions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kr_period_closure_revisions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kr_period_closure_revisions_id_seq OWNED BY public.kr_period_closure_revisions.id;


--
-- Name: kr_period_fact_revisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kr_period_fact_revisions (
    id integer NOT NULL,
    period_id integer NOT NULL,
    revision_no integer NOT NULL,
    previous_revision_id integer,
    value numeric(30,10) NOT NULL,
    as_of_date date NOT NULL,
    status character varying(16) NOT NULL,
    source text NOT NULL,
    comment text NOT NULL,
    reason text NOT NULL,
    source_measurement_id integer,
    source_measurement_snapshot json,
    numerator numeric(30,10),
    denominator numeric(30,10),
    author_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: kr_period_fact_revisions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kr_period_fact_revisions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kr_period_fact_revisions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kr_period_fact_revisions_id_seq OWNED BY public.kr_period_fact_revisions.id;


--
-- Name: kr_period_plan_revisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kr_period_plan_revisions (
    id integer NOT NULL,
    period_id integer NOT NULL,
    revision_no integer NOT NULL,
    previous_revision_id integer,
    data json NOT NULL,
    author_id integer NOT NULL,
    reason text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: kr_period_plan_revisions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kr_period_plan_revisions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kr_period_plan_revisions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kr_period_plan_revisions_id_seq OWNED BY public.kr_period_plan_revisions.id;


--
-- Name: kr_periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kr_periods (
    id integer NOT NULL,
    metric_id integer NOT NULL,
    label character varying(120) NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    state character varying(16) DEFAULT 'draft'::character varying NOT NULL,
    direction character varying(10),
    baseline numeric(30,10),
    baseline_date date,
    target numeric(30,10),
    upper numeric(30,10),
    cadence character varying(16) DEFAULT 'weekly'::character varying NOT NULL,
    interval_days integer,
    first_due_date date,
    weight numeric(6,2),
    forecast numeric(6,2),
    method_snapshot text,
    source_snapshot text,
    unit_snapshot character varying(50),
    outcome character varying(32),
    closing_note text,
    closed_at timestamp with time zone,
    legacy_fact numeric(30,10),
    model_version character varying(16) DEFAULT 'legacy_v1'::character varying NOT NULL,
    calendar_year integer,
    quarter integer,
    current_plan_revision_id integer,
    current_fact_revision_id integer,
    closure_revision_id integer,
    result_type character varying(16),
    CONSTRAINT ck_kr_period_cadence CHECK (((cadence)::text = ANY ((ARRAY['none'::character varying, 'daily'::character varying, 'weekly'::character varying, 'monthly'::character varying, 'quarterly'::character varying, 'interval'::character varying])::text[]))),
    CONSTRAINT ck_kr_period_dates CHECK ((start_date <= end_date)),
    CONSTRAINT ck_kr_period_direction CHECK (((direction IS NULL) OR ((direction)::text = ANY ((ARRAY['up'::character varying, 'down'::character varying, 'range'::character varying])::text[])))),
    CONSTRAINT ck_kr_period_interval CHECK (((interval_days IS NULL) OR ((interval_days >= 1) AND (interval_days <= 366)))),
    CONSTRAINT ck_kr_period_state CHECK (((state)::text = ANY ((ARRAY['draft'::character varying, 'active'::character varying, 'completed'::character varying, 'cancelled'::character varying])::text[]))),
    CONSTRAINT ck_kr_quarter_calendar CHECK ((((model_version)::text <> 'quarterly_v2'::text) OR ((calendar_year IS NOT NULL) AND ((quarter >= 1) AND (quarter <= 4)) AND ((calendar_year)::numeric = EXTRACT(year FROM start_date)) AND (start_date = make_date(calendar_year, ((quarter * 3) - 2), 1)) AND (end_date = (((start_date + '3 mons'::interval) - '1 day'::interval))::date))))
);


--
-- Name: kr_periods_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kr_periods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kr_periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kr_periods_id_seq OWNED BY public.kr_periods.id;


--
-- Name: kr_reporting_statuses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kr_reporting_statuses (
    id integer NOT NULL,
    metric_id integer NOT NULL,
    period_id integer NOT NULL,
    meeting_id integer NOT NULL,
    text text NOT NULL,
    snapshot json NOT NULL,
    author_id integer NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: kr_reporting_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kr_reporting_statuses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kr_reporting_statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kr_reporting_statuses_id_seq OWNED BY public.kr_reporting_statuses.id;


--
-- Name: kr_year_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kr_year_settings (
    id integer NOT NULL,
    metric_id integer NOT NULL,
    year integer NOT NULL,
    expected_quarters json NOT NULL,
    exclusions json NOT NULL,
    aggregation character varying(10) NOT NULL,
    scale integer NOT NULL
);


--
-- Name: kr_year_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kr_year_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kr_year_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kr_year_settings_id_seq OWNED BY public.kr_year_settings.id;


--
-- Name: login_reservations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.login_reservations (
    login_normalized character varying(254) NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    retired_at timestamp with time zone
);


--
-- Name: major_external_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.major_external_links (
    id integer NOT NULL,
    major_task_id integer,
    url character varying(2000) NOT NULL,
    created_by integer NOT NULL,
    version integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: major_external_links_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.major_external_links_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: major_external_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.major_external_links_id_seq OWNED BY public.major_external_links.id;


--
-- Name: meeting_actions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meeting_actions (
    id integer NOT NULL,
    capture_id character varying(36) NOT NULL,
    item_id character varying(64) NOT NULL,
    task_id integer,
    kind character varying(16) NOT NULL,
    title character varying(255) NOT NULL,
    description text NOT NULL,
    owner_text character varying(255) NOT NULL,
    due_date date,
    due_text character varying(255) NOT NULL,
    quote text NOT NULL,
    origin character varying(16) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: meeting_actions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.meeting_actions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: meeting_actions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.meeting_actions_id_seq OWNED BY public.meeting_actions.id;


--
-- Name: meeting_application_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meeting_application_receipts (
    service_run_id character varying(36) NOT NULL,
    consumer_operation_id character varying(36) NOT NULL,
    capture_id character varying(36) NOT NULL,
    owner_id integer NOT NULL,
    source_hash character varying(64) NOT NULL,
    payload_hash character varying(64),
    source_revision integer,
    applied_object_refs json DEFAULT '[]'::json NOT NULL,
    committed_at timestamp with time zone,
    decision character varying(16) NOT NULL,
    ack_pending boolean DEFAULT true NOT NULL,
    ack_attempts integer DEFAULT 0 NOT NULL,
    next_attempt_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    CONSTRAINT ck_meeting_receipt_decision CHECK (((decision)::text = ANY ((ARRAY['pending'::character varying, 'applied'::character varying, 'discarded'::character varying])::text[])))
);


--
-- Name: meeting_captures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meeting_captures (
    id character varying(36) NOT NULL,
    owner_id integer NOT NULL,
    title character varying(255) NOT NULL,
    meeting_date date,
    transcript text NOT NULL,
    items json NOT NULL,
    version integer NOT NULL,
    status character varying(16) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    analysis_status character varying(16) DEFAULT 'idle'::character varying NOT NULL,
    analysis_run_id character varying(36),
    analysis_requested_at timestamp with time zone,
    analysis_started_at timestamp with time zone,
    analysis_finished_at timestamp with time zone,
    analysis_error_code character varying(32),
    analysis_backend character varying(32) DEFAULT 'legacy'::character varying NOT NULL,
    analysis_service_run_id character varying(36),
    analysis_ack_pending boolean DEFAULT false NOT NULL
);


--
-- Name: meeting_delivery_intents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meeting_delivery_intents (
    operation_id character varying(36) NOT NULL,
    capture_id character varying(36) NOT NULL,
    owner_id integer NOT NULL,
    source_revision integer NOT NULL,
    payload json,
    phase character varying(16) NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    next_attempt_at timestamp with time zone,
    error_code character varying(64),
    requested_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    CONSTRAINT ck_meeting_intent_phase CHECK (((phase)::text = ANY ((ARRAY['queued'::character varying, 'unknown'::character varying, 'resolved'::character varying])::text[])))
);


--
-- Name: notification_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_templates (
    id integer NOT NULL,
    name character varying(150) NOT NULL,
    event_type character varying(50) NOT NULL,
    text text NOT NULL,
    recipients text NOT NULL,
    deadline_days integer,
    repeat_frequency character varying(20),
    repeat_day integer,
    is_active boolean NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: COLUMN notification_templates.recipients; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.notification_templates.recipients IS 'JSON array of recipient role codes';


--
-- Name: notification_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notification_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notification_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notification_templates_id_seq OWNED BY public.notification_templates.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    user_id integer NOT NULL,
    task_id integer,
    type character varying(50) NOT NULL,
    message character varying(500) NOT NULL,
    category character varying(50) NOT NULL,
    title character varying(300) NOT NULL,
    body text,
    importance character varying(20),
    is_read boolean,
    is_dismissed boolean,
    is_resolved boolean,
    action_url character varying(200),
    group_key character varying(100),
    group_count integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    read_at timestamp with time zone,
    resolved_at timestamp with time zone,
    work_task_id integer,
    CONSTRAINT ck_notification_work_target CHECK (((task_id IS NULL) OR (work_task_id IS NULL)))
);


--
-- Name: COLUMN notifications.type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.notifications.type IS 'Тип уведомления: system, status_change, assignment, mention, comment, lock';


--
-- Name: COLUMN notifications.message; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.notifications.message IS 'Краткое сообщение (для обратной совместимости)';


--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: priorities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.priorities (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


--
-- Name: priorities_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.priorities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: priorities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.priorities_id_seq OWNED BY public.priorities.id;


--
-- Name: project_statuses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_statuses (
    id integer NOT NULL,
    code character varying(50) NOT NULL,
    name character varying(100) NOT NULL
);


--
-- Name: project_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_statuses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.project_statuses_id_seq OWNED BY public.project_statuses.id;


--
-- Name: project_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_tags (
    id integer NOT NULL,
    project_id integer NOT NULL,
    tag_id integer NOT NULL
);


--
-- Name: project_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.project_tags_id_seq OWNED BY public.project_tags.id;


--
-- Name: project_task_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_task_plans (
    task_id integer NOT NULL,
    starts_on date,
    ends_on date,
    baseline_start date,
    baseline_end date,
    is_milestone boolean DEFAULT false NOT NULL,
    expected_result text DEFAULT ''::text NOT NULL,
    change_reason text DEFAULT ''::text NOT NULL,
    CONSTRAINT ck_project_plan_dates CHECK ((((starts_on IS NULL) AND (ends_on IS NULL)) OR ((starts_on IS NOT NULL) AND (ends_on IS NOT NULL) AND (starts_on <= ends_on))))
);


--
-- Name: projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects (
    id integer NOT NULL,
    code character varying(50) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    status_id integer,
    responsible_pl integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: projects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.projects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.projects_id_seq OWNED BY public.projects.id;


--
-- Name: refresh_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.refresh_sessions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    jti character varying(36) NOT NULL,
    family_id character varying(36) NOT NULL,
    token_hash character varying(64) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    rotated_to_jti character varying(36),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    auth_session_id character varying(36)
);


--
-- Name: refresh_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.refresh_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: refresh_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.refresh_sessions_id_seq OWNED BY public.refresh_sessions.id;


--
-- Name: reporting_meeting_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reporting_meeting_history (
    id integer NOT NULL,
    meeting_id integer NOT NULL,
    action character varying(30) NOT NULL,
    old_state character varying(20),
    new_state character varying(20),
    old_date date,
    new_date date,
    reason text,
    changed_by integer,
    changed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: reporting_meeting_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reporting_meeting_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reporting_meeting_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.reporting_meeting_history_id_seq OWNED BY public.reporting_meeting_history.id;


--
-- Name: reporting_meetings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reporting_meetings (
    id integer NOT NULL,
    kind character varying(30) NOT NULL,
    occurrence_key character varying(80) NOT NULL,
    scheduled_date date,
    original_scheduled_date date,
    state character varying(20) NOT NULL,
    change_reason text,
    held_at timestamp with time zone,
    cancelled_at timestamp with time zone,
    team_reminder_sent_at timestamp with time zone,
    admin_fact_notified_at timestamp with time zone,
    version integer NOT NULL,
    created_by integer,
    updated_by integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: reporting_meetings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reporting_meetings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reporting_meetings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.reporting_meetings_id_seq OWNED BY public.reporting_meetings.id;


--
-- Name: reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reports (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    type character varying(20),
    key character varying(100),
    created_by integer,
    filters text,
    fields text,
    group_by character varying(50),
    sort_by character varying(50),
    sort_order character varying(4),
    is_public boolean,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    version integer DEFAULT 0 NOT NULL
);


--
-- Name: reports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.reports_id_seq OWNED BY public.reports.id;


--
-- Name: request_work_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.request_work_links (
    id integer NOT NULL,
    request_id integer NOT NULL,
    major_task_id integer,
    work_task_id integer,
    is_active boolean DEFAULT true NOT NULL,
    request_revision integer NOT NULL,
    requirement_snapshot json NOT NULL,
    scope_text text NOT NULL,
    coverage character varying(16) NOT NULL,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_request_work_coverage CHECK (((coverage)::text = ANY ((ARRAY['full'::character varying, 'partial'::character varying])::text[]))),
    CONSTRAINT ck_request_work_target CHECK ((((major_task_id IS NOT NULL) AND (work_task_id IS NULL)) OR ((major_task_id IS NULL) AND (work_task_id IS NOT NULL)) OR (NOT is_active)))
);


--
-- Name: request_work_links_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.request_work_links_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: request_work_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.request_work_links_id_seq OWNED BY public.request_work_links.id;


--
-- Name: requirement_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.requirement_requests (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    draft json,
    status character varying(20),
    agent_session_id character varying(64),
    user_id integer NOT NULL,
    team_id integer,
    reviewer_id integer,
    assignee_id integer,
    task_id integer,
    reject_reason text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    is_deleted boolean,
    version integer NOT NULL,
    revision_history json DEFAULT '[]'::json NOT NULL,
    status_history json DEFAULT '[]'::json NOT NULL,
    coordinator_id integer,
    next_action character varying(500),
    next_action_due date
);


--
-- Name: requirement_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.requirement_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: requirement_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.requirement_requests_id_seq OWNED BY public.requirement_requests.id;


--
-- Name: requirement_reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.requirement_reviews (
    id integer NOT NULL,
    artifact_id character varying(128) NOT NULL,
    active_artifact_id character varying(128),
    artifact_revision integer NOT NULL,
    artifact_fingerprint character varying(71) NOT NULL,
    artifact_snapshot json NOT NULL,
    review_report json NOT NULL,
    title character varying(255) NOT NULL,
    session_id character varying(128) NOT NULL,
    creator_id integer NOT NULL,
    team_id integer,
    reviewer_id integer,
    source_request_author_id integer,
    target_type character varying(20),
    target_id integer,
    source_metadata json NOT NULL,
    status character varying(20) NOT NULL,
    comment text NOT NULL,
    events json NOT NULL,
    idempotency_key character varying(128) NOT NULL,
    submission_hash character varying(71) NOT NULL,
    version integer NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT ck_requirement_review_active CHECK (((((status)::text = 'submitted'::text) AND (active_artifact_id IS NOT NULL) AND ((active_artifact_id)::text = (artifact_id)::text)) OR (((status)::text <> 'submitted'::text) AND (active_artifact_id IS NULL)))),
    CONSTRAINT ck_requirement_review_status CHECK (((status)::text = ANY ((ARRAY['submitted'::character varying, 'returned'::character varying, 'approved'::character varying, 'withdrawn'::character varying])::text[]))),
    CONSTRAINT ck_requirement_review_target CHECK ((((target_type IS NULL) AND (target_id IS NULL)) OR ((target_type IS NOT NULL) AND ((target_type)::text = ANY ((ARRAY['task'::character varying, 'request'::character varying])::text[])) AND (target_id IS NOT NULL)))),
    CONSTRAINT ck_requirement_review_versions CHECK (((artifact_revision > 0) AND (version > 0)))
);


--
-- Name: requirement_reviews_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.requirement_reviews_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: requirement_reviews_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.requirement_reviews_id_seq OWNED BY public.requirement_reviews.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    status character varying(20),
    description text,
    backlog_dmb_access character varying(20),
    backlog_team_access character varying(20),
    reports_access character varying(20),
    analytics_access character varying(20),
    customer_access character varying(20),
    settings_access character varying(20),
    admin_access character varying(20),
    customer_portal_only boolean,
    review_access character varying(20),
    task_edit_scope character varying(20),
    task_comment_scope character varying(20),
    task_delete_scope character varying(20),
    pip_decision_access boolean,
    can_edit_tasks boolean,
    can_delete_tasks boolean,
    can_export boolean,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: security_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.security_events (
    id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    actor_id integer,
    subject_id integer,
    session_id character varying(36),
    action character varying(64) NOT NULL,
    outcome character varying(16) NOT NULL,
    reason character varying(256),
    request_id character varying(64),
    ip_address character varying(64)
);


--
-- Name: security_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.security_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: security_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.security_events_id_seq OWNED BY public.security_events.id;


--
-- Name: start_shifts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.start_shifts (
    id integer NOT NULL,
    code character varying(20) NOT NULL,
    name character varying(100) NOT NULL,
    month_number integer NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    CONSTRAINT ck_start_shifts_month_number CHECK (((month_number >= 1) AND (month_number <= 3)))
);


--
-- Name: start_shifts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.start_shifts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: start_shifts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.start_shifts_id_seq OWNED BY public.start_shifts.id;


--
-- Name: statuses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.statuses (
    id integer NOT NULL,
    code character varying(50) NOT NULL,
    name character varying(100) NOT NULL,
    sort_order integer,
    color character varying(20)
);


--
-- Name: statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.statuses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.statuses_id_seq OWNED BY public.statuses.id;


--
-- Name: stories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stories (
    id integer NOT NULL,
    epic_id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    effort_designee double precision,
    effort_analytics double precision,
    effort_be double precision,
    effort_python_be double precision,
    effort_fe double precision,
    effort_test double precision,
    effort_test_auto double precision,
    effort_delivery double precision,
    sort_order integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    progress integer DEFAULT 0
);


--
-- Name: COLUMN stories.effort_designee; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stories.effort_designee IS 'Designee (дни)';


--
-- Name: COLUMN stories.effort_analytics; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stories.effort_analytics IS 'Аналитика (дни)';


--
-- Name: COLUMN stories.effort_be; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stories.effort_be IS 'Разработка BE (дни)';


--
-- Name: COLUMN stories.effort_python_be; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stories.effort_python_be IS 'Разработка python BE (дни)';


--
-- Name: COLUMN stories.effort_fe; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stories.effort_fe IS 'Разработка FE (дни)';


--
-- Name: COLUMN stories.effort_test; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stories.effort_test IS 'Tester (дни)';


--
-- Name: COLUMN stories.effort_test_auto; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stories.effort_test_auto IS 'Tester Auto (дни)';


--
-- Name: COLUMN stories.effort_delivery; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stories.effort_delivery IS 'Delivery (дни)';


--
-- Name: COLUMN stories.sort_order; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stories.sort_order IS 'Порядок сортировки';


--
-- Name: stories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stories_id_seq OWNED BY public.stories.id;


--
-- Name: tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tags (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    color character varying(20),
    description text,
    code character varying(50),
    sort_order integer,
    is_active boolean,
    version integer,
    lock_owner_id integer,
    lock_until timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    creator integer,
    progress integer DEFAULT 0
);


--
-- Name: tags_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tags_id_seq OWNED BY public.tags.id;


--
-- Name: task_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_attachments (
    id integer NOT NULL,
    task_id integer NOT NULL,
    user_id integer NOT NULL,
    filename character varying(255) NOT NULL,
    original_name character varying(255) NOT NULL,
    mime_type character varying(100),
    file_size integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: task_attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.task_attachments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: task_attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.task_attachments_id_seq OWNED BY public.task_attachments.id;


--
-- Name: task_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_comments (
    id integer NOT NULL,
    task_id integer NOT NULL,
    user_id integer,
    parent_id integer,
    text text NOT NULL,
    mentioned_user_ids text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    legacy_references json
);


--
-- Name: COLUMN task_comments.mentioned_user_ids; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.task_comments.mentioned_user_ids IS 'JSON array of mentioned user IDs';


--
-- Name: task_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.task_comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: task_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.task_comments_id_seq OWNED BY public.task_comments.id;


--
-- Name: task_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_history (
    id integer NOT NULL,
    task_id integer NOT NULL,
    changed_by integer,
    changed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    field_name character varying(50) NOT NULL,
    old_value text,
    new_value text,
    legacy_references json
);


--
-- Name: task_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.task_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: task_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.task_history_id_seq OWNED BY public.task_history.id;


--
-- Name: task_jira_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_jira_links (
    id integer NOT NULL,
    task_id integer NOT NULL,
    url character varying(500) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: task_jira_links_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.task_jira_links_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: task_jira_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.task_jira_links_id_seq OWNED BY public.task_jira_links.id;


--
-- Name: task_reporting_status_revisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_reporting_status_revisions (
    id integer NOT NULL,
    reporting_status_id integer NOT NULL,
    old_text text,
    new_text text,
    old_did_demo boolean,
    new_did_demo boolean,
    changed_by integer,
    changed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    old_weekly_payload json,
    new_weekly_payload json
);


--
-- Name: task_reporting_status_revisions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.task_reporting_status_revisions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: task_reporting_status_revisions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.task_reporting_status_revisions_id_seq OWNED BY public.task_reporting_status_revisions.id;


--
-- Name: task_reporting_statuses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_reporting_statuses (
    id integer NOT NULL,
    meeting_id integer NOT NULL,
    task_id integer NOT NULL,
    status_text text,
    did_demo boolean NOT NULL,
    source character varying(30) NOT NULL,
    carried_from_status_id integer,
    version integer NOT NULL,
    created_by integer,
    updated_by integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    is_ready boolean NOT NULL,
    directorate_attention boolean NOT NULL,
    weekly_payload json,
    progress_snapshot integer,
    task_status_snapshot character varying(100)
);


--
-- Name: task_reporting_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.task_reporting_statuses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: task_reporting_statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.task_reporting_statuses_id_seq OWNED BY public.task_reporting_statuses.id;


--
-- Name: task_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_types (
    id integer NOT NULL,
    code character varying(50) NOT NULL,
    name character varying(100) NOT NULL
);


--
-- Name: task_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.task_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: task_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.task_types_id_seq OWNED BY public.task_types.id;


--
-- Name: task_viewers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_viewers (
    id integer NOT NULL,
    task_id integer NOT NULL,
    user_id integer NOT NULL,
    last_seen_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: task_viewers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.task_viewers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: task_viewers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.task_viewers_id_seq OWNED BY public.task_viewers.id;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tasks (
    id integer NOT NULL,
    public_id character varying(12),
    team_id integer,
    title character varying(255) NOT NULL,
    description text,
    date_received date,
    channel_id integer,
    business_customer_id integer,
    department_id integer,
    project_id integer,
    task_type_id integer,
    involved_teams json,
    priority_id integer,
    status_id integer,
    previous_status_id integer,
    deadline_id integer,
    effort_days integer,
    effort_rub numeric(18,2),
    effort_designee double precision,
    effort_analytics double precision,
    effort_be double precision,
    effort_python_be double precision,
    effort_fe double precision,
    effort_test double precision,
    effort_test_auto double precision,
    effort_delivery double precision,
    actual_effort_days double precision,
    actual_effort_designee double precision,
    actual_effort_analytics double precision,
    actual_effort_be double precision,
    actual_effort_fe double precision,
    actual_effort_test double precision,
    actual_effort_test_auto double precision,
    actual_effort_python_be double precision,
    actual_effort_delivery double precision,
    financial_effect_justification text,
    financial_effect numeric(18,2),
    financial_effect_ai numeric(18,2),
    financial_effect_ai_justification text,
    priority_score integer,
    priority_justification text,
    assessment_weight double precision,
    completion_forecast double precision,
    hard_score character varying(1),
    soft_score character varying(1),
    cv double precision,
    progress integer,
    link_mockups character varying(500),
    link_jira json,
    link_requirements json,
    rejection_reason text,
    comment text,
    owner_id integer,
    key_project_status text,
    key_project_status_updated_at timestamp with time zone,
    prev_key_project_status text,
    directorate_status text,
    directorate_status_updated_at timestamp with time zone,
    prev_directorate_status text,
    did_status text,
    did_status_updated_at timestamp with time zone,
    prev_did_status text,
    did_demo boolean,
    metric_kr_plan double precision,
    metric_kr_fact double precision,
    metric_kr_unit character varying(50),
    created_by integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    is_deleted boolean,
    version integer,
    lock_owner_id integer,
    lock_until timestamp with time zone,
    legacy_references json,
    did_client_group_id integer,
    start_shift_id integer,
    progress_updated_at timestamp with time zone,
    metric_id integer
);


--
-- Name: COLUMN tasks.involved_teams; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.involved_teams IS 'Другие вовлечённые команды (массив id команд)';


--
-- Name: COLUMN tasks.previous_status_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.previous_status_id IS 'Статус до перевода в ЭКСПРЕСС-ОЦЕНКА';


--
-- Name: COLUMN tasks.effort_rub; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.effort_rub IS 'Стоимость по ЭО (руб)';


--
-- Name: COLUMN tasks.effort_designee; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.effort_designee IS 'Designee (дни)';


--
-- Name: COLUMN tasks.effort_analytics; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.effort_analytics IS 'Аналитика (дни)';


--
-- Name: COLUMN tasks.effort_be; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.effort_be IS 'Разработка BE (дни)';


--
-- Name: COLUMN tasks.effort_python_be; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.effort_python_be IS 'Разработка python BE (дни)';


--
-- Name: COLUMN tasks.effort_fe; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.effort_fe IS 'Разработка FE (дни)';


--
-- Name: COLUMN tasks.effort_test; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.effort_test IS 'Tester (дни)';


--
-- Name: COLUMN tasks.effort_test_auto; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.effort_test_auto IS 'Tester Auto (дни)';


--
-- Name: COLUMN tasks.effort_delivery; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.effort_delivery IS 'Delivery (дни)';


--
-- Name: COLUMN tasks.actual_effort_days; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.actual_effort_days IS 'Фактические трудозатраты (ч/д)';


--
-- Name: COLUMN tasks.actual_effort_designee; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.actual_effort_designee IS 'Designee (ФТЗ)';


--
-- Name: COLUMN tasks.actual_effort_analytics; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.actual_effort_analytics IS 'Аналитика (ФТЗ)';


--
-- Name: COLUMN tasks.actual_effort_be; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.actual_effort_be IS 'Разработка BE (ФТЗ)';


--
-- Name: COLUMN tasks.actual_effort_fe; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.actual_effort_fe IS 'Разработка FE (ФТЗ)';


--
-- Name: COLUMN tasks.actual_effort_test; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.actual_effort_test IS 'Test (ФТЗ)';


--
-- Name: COLUMN tasks.actual_effort_test_auto; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.actual_effort_test_auto IS 'Test Auto (ФТЗ)';


--
-- Name: COLUMN tasks.actual_effort_python_be; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.actual_effort_python_be IS 'Разработка python BE (ФТЗ)';


--
-- Name: COLUMN tasks.actual_effort_delivery; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.actual_effort_delivery IS 'Delivery (ФТЗ)';


--
-- Name: COLUMN tasks.financial_effect_justification; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.financial_effect_justification IS 'Обоснование по расчету финансового эффекта';


--
-- Name: COLUMN tasks.financial_effect_ai; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.financial_effect_ai IS 'AI-расчёт финансового эффекта (руб)';


--
-- Name: COLUMN tasks.financial_effect_ai_justification; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.financial_effect_ai_justification IS 'Обоснование AI-расчёта финансового эффекта';


--
-- Name: COLUMN tasks.priority_score; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.priority_score IS 'Priority Score (рейтинг 0-100)';


--
-- Name: COLUMN tasks.priority_justification; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.priority_justification IS 'Обоснование Priority Score';


--
-- Name: COLUMN tasks.assessment_weight; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.assessment_weight IS 'Вес оценки (%)';


--
-- Name: COLUMN tasks.completion_forecast; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.completion_forecast IS 'Прогноз выполнения (%)';


--
-- Name: COLUMN tasks.hard_score; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.hard_score IS 'Оценка за завершенность (Hard): A, B, C, D, E';


--
-- Name: COLUMN tasks.soft_score; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.soft_score IS 'Оценка за взаимодействие (Soft): A, B, C, D, E';


--
-- Name: COLUMN tasks.link_jira; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.link_jira IS 'Ссылки на Jira (массив ссылок)';


--
-- Name: COLUMN tasks.link_requirements; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.link_requirements IS 'Ссылки на бизнес-требования (массив ссылок)';


--
-- Name: COLUMN tasks.key_project_status_updated_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.key_project_status_updated_at IS 'Дата изменения статуса для встречи по ключевым проектам';


--
-- Name: COLUMN tasks.prev_key_project_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.prev_key_project_status IS 'Статус предыдущей встречи по ключевым проектам';


--
-- Name: COLUMN tasks.prev_directorate_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.prev_directorate_status IS 'Статус предыдущей директорской оперативки';


--
-- Name: COLUMN tasks.prev_did_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.prev_did_status IS 'Статус предыдущей оперативки ДИД';


--
-- Name: COLUMN tasks.did_demo; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.did_demo IS 'Демо для ДИД';


--
-- Name: COLUMN tasks.metric_kr_plan; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.metric_kr_plan IS 'Значение для метрического KR (план)';


--
-- Name: COLUMN tasks.metric_kr_fact; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.metric_kr_fact IS 'Значение для метрического KR (факт)';


--
-- Name: COLUMN tasks.metric_kr_unit; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.metric_kr_unit IS 'Единица измерения Метрического KR';


--
-- Name: COLUMN tasks.version; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tasks.version IS 'Версия задачи (optimistic lock)';


--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: team_competency_resources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team_competency_resources (
    id integer NOT NULL,
    team_id integer NOT NULL,
    competency character varying(50) NOT NULL,
    senior_count integer,
    middle_count integer,
    junior_count integer,
    vacation_days integer,
    working_days integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: COLUMN team_competency_resources.competency; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.team_competency_resources.competency IS 'Компетенция';


--
-- Name: COLUMN team_competency_resources.senior_count; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.team_competency_resources.senior_count IS 'Кол-во Senior';


--
-- Name: COLUMN team_competency_resources.middle_count; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.team_competency_resources.middle_count IS 'Кол-во Middle';


--
-- Name: COLUMN team_competency_resources.junior_count; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.team_competency_resources.junior_count IS 'Кол-во Junior';


--
-- Name: COLUMN team_competency_resources.vacation_days; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.team_competency_resources.vacation_days IS 'Дни отпуска';


--
-- Name: COLUMN team_competency_resources.working_days; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.team_competency_resources.working_days IS 'Рабочие дни в квартале';


--
-- Name: team_competency_resources_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.team_competency_resources_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: team_competency_resources_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.team_competency_resources_id_seq OWNED BY public.team_competency_resources.id;


--
-- Name: team_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team_types (
    id integer NOT NULL,
    code character varying(50) NOT NULL,
    name character varying(100) NOT NULL
);


--
-- Name: team_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.team_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: team_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.team_types_id_seq OWNED BY public.team_types.id;


--
-- Name: teams; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.teams (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    team_type_id integer,
    color character varying(20),
    domain character varying(200),
    description text,
    pl character varying(100),
    po character varying(100),
    cl character varying(100),
    it_pl character varying(100),
    pl_id integer,
    po_id integer,
    cl_id integer,
    it_pl_id integer,
    abbr character varying(10),
    members text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: teams_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.teams_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: teams_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.teams_id_seq OWNED BY public.teams.id;


--
-- Name: timeline_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.timeline_events (
    id integer NOT NULL,
    title character varying(300) NOT NULL,
    description text,
    event_type character varying(50),
    color character varying(20),
    date date NOT NULL,
    quarter integer,
    month integer,
    year integer NOT NULL,
    project_id integer,
    is_recurring boolean,
    recurring_interval character varying(20),
    visibility_level character varying(20),
    creator_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: timeline_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.timeline_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: timeline_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.timeline_events_id_seq OWNED BY public.timeline_events.id;


--
-- Name: user_notification_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_notification_preferences (
    id integer NOT NULL,
    user_id integer NOT NULL,
    preferences text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: user_notification_preferences_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_notification_preferences_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_notification_preferences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_notification_preferences_id_seq OWNED BY public.user_notification_preferences.id;


--
-- Name: user_report_prefs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_report_prefs (
    id integer NOT NULL,
    user_id integer NOT NULL,
    report_key character varying(50) NOT NULL,
    prefs json NOT NULL,
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: user_report_prefs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_report_prefs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_report_prefs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_report_prefs_id_seq OWNED BY public.user_report_prefs.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    login character varying(254),
    email character varying(255),
    password_hash character varying(255),
    name character varying(100) NOT NULL,
    "position" character varying(100),
    team_id integer,
    role_id integer,
    business_customer_id integer,
    can_edit boolean,
    can_delete boolean,
    can_export boolean,
    is_active boolean,
    last_login timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    login_normalized character varying(254),
    credential_state character varying(20) DEFAULT 'invited'::character varying NOT NULL,
    auth_version bigint DEFAULT '1'::bigint NOT NULL,
    password_changed_at timestamp with time zone,
    password_normalization_version integer DEFAULT 1 NOT NULL,
    CONSTRAINT ck_user_credentials CHECK (((credential_state)::text = ANY ((ARRAY['invited'::character varying, 'ready'::character varying, 'reset_required'::character varying])::text[]))),
    CONSTRAINT ck_user_password_present CHECK ((((credential_state)::text = 'invited'::text) OR (password_hash IS NOT NULL)))
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: work_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_attachments (
    id integer NOT NULL,
    work_task_id integer NOT NULL,
    author_id integer NOT NULL,
    filename character varying(255) NOT NULL,
    storage_key character varying(64) NOT NULL,
    size integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: work_attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.work_attachments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: work_attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.work_attachments_id_seq OWNED BY public.work_attachments.id;


--
-- Name: work_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_comments (
    id integer NOT NULL,
    work_task_id integer NOT NULL,
    author_id integer NOT NULL,
    body text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: work_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.work_comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: work_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.work_comments_id_seq OWNED BY public.work_comments.id;


--
-- Name: work_dependencies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_dependencies (
    id integer NOT NULL,
    source_major_id integer,
    source_work_id integer,
    target_major_id integer,
    target_work_id integer,
    created_by integer NOT NULL,
    version integer NOT NULL,
    is_active boolean NOT NULL,
    reason text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_dependency_source CHECK ((((source_major_id IS NOT NULL) AND (source_work_id IS NULL)) OR ((source_major_id IS NULL) AND (source_work_id IS NOT NULL)) OR (NOT is_active))),
    CONSTRAINT ck_dependency_target CHECK ((((target_major_id IS NOT NULL) AND (target_work_id IS NULL)) OR ((target_major_id IS NULL) AND (target_work_id IS NOT NULL)) OR (NOT is_active)))
);


--
-- Name: work_dependencies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.work_dependencies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: work_dependencies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.work_dependencies_id_seq OWNED BY public.work_dependencies.id;


--
-- Name: work_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_history (
    id integer NOT NULL,
    work_task_id integer NOT NULL,
    actor_id integer NOT NULL,
    action character varying(40) NOT NULL,
    version integer NOT NULL,
    before json NOT NULL,
    after json NOT NULL,
    reason text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: work_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.work_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: work_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.work_history_id_seq OWNED BY public.work_history.id;


--
-- Name: work_meeting_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_meeting_snapshots (
    meeting_id integer NOT NULL,
    schema_version integer NOT NULL,
    payload json NOT NULL,
    captured_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: work_resolutions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_resolutions (
    id integer NOT NULL,
    request_id integer NOT NULL,
    review_decision character varying(30) NOT NULL,
    decided_by integer NOT NULL,
    decided_at timestamp with time zone DEFAULT now() NOT NULL,
    coverage character varying(16) NOT NULL,
    fulfillment character varying(24) NOT NULL,
    result_text text NOT NULL,
    confirmed_work_revisions json
);


--
-- Name: work_resolutions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.work_resolutions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: work_resolutions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.work_resolutions_id_seq OWNED BY public.work_resolutions.id;


--
-- Name: work_task_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_task_templates (
    id integer NOT NULL,
    owner_id integer NOT NULL,
    name character varying(120) NOT NULL,
    content json NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_work_template_version CHECK ((version > 0))
);


--
-- Name: work_task_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.work_task_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: work_task_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.work_task_templates_id_seq OWNED BY public.work_task_templates.id;


--
-- Name: work_tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_tasks (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text NOT NULL,
    work_direction character varying(20) NOT NULL,
    major_task_id integer,
    direct_project_id integer,
    requester_id integer NOT NULL,
    requester_team_id integer,
    execution_team_id integer NOT NULL,
    assignee_id integer,
    acceptor_id integer,
    created_by integer NOT NULL,
    due_date date,
    status character varying(20) NOT NULL,
    assignment_state character varying(16) NOT NULL,
    acceptance_required boolean NOT NULL,
    result_text text NOT NULL,
    completed_at timestamp with time zone,
    version integer NOT NULL,
    is_deleted boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    result_revision integer DEFAULT 1 NOT NULL,
    return_reason text,
    priority character varying(10) DEFAULT 'normal'::character varying NOT NULL,
    checklist json DEFAULT '[]'::json NOT NULL,
    CONSTRAINT ck_work_assignment CHECK (((assignment_state)::text = ANY ((ARRAY['proposed'::character varying, 'accepted'::character varying, 'declined'::character varying])::text[]))),
    CONSTRAINT ck_work_context CHECK (((major_task_id IS NULL) OR (direct_project_id IS NULL))),
    CONSTRAINT ck_work_direction CHECK (((work_direction)::text = ANY ((ARRAY['product'::character varying, 'organizational'::character varying])::text[]))),
    CONSTRAINT ck_work_priority CHECK (((priority)::text = ANY ((ARRAY['low'::character varying, 'normal'::character varying, 'high'::character varying, 'urgent'::character varying])::text[]))),
    CONSTRAINT ck_work_status CHECK (((status)::text = ANY ((ARRAY['new'::character varying, 'ready'::character varying, 'in_progress'::character varying, 'in_acceptance'::character varying, 'done'::character varying, 'cancelled'::character varying])::text[]))),
    CONSTRAINT ck_work_version CHECK ((version > 0))
);


--
-- Name: work_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.work_tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: work_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.work_tasks_id_seq OWNED BY public.work_tasks.id;


--
-- Name: agent_sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_sessions ALTER COLUMN id SET DEFAULT nextval('public.agent_sessions_id_seq'::regclass);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: business_customers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.business_customers ALTER COLUMN id SET DEFAULT nextval('public.business_customers_id_seq'::regclass);


--
-- Name: channels id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channels ALTER COLUMN id SET DEFAULT nextval('public.channels_id_seq'::regclass);


--
-- Name: column_labels id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.column_labels ALTER COLUMN id SET DEFAULT nextval('public.column_labels_id_seq'::regclass);


--
-- Name: competency_cost_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.competency_cost_history ALTER COLUMN id SET DEFAULT nextval('public.competency_cost_history_id_seq'::regclass);


--
-- Name: deadlines id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deadlines ALTER COLUMN id SET DEFAULT nextval('public.deadlines_id_seq'::regclass);


--
-- Name: departments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments ALTER COLUMN id SET DEFAULT nextval('public.departments_id_seq'::regclass);


--
-- Name: dictionary_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dictionary_items ALTER COLUMN id SET DEFAULT nextval('public.dictionary_items_id_seq'::regclass);


--
-- Name: did_client_groups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.did_client_groups ALTER COLUMN id SET DEFAULT nextval('public.did_client_groups_id_seq'::regclass);


--
-- Name: display_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.display_settings ALTER COLUMN id SET DEFAULT nextval('public.display_settings_id_seq'::regclass);


--
-- Name: effort_rub_normalization_audit task_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.effort_rub_normalization_audit ALTER COLUMN task_id SET DEFAULT nextval('public.effort_rub_normalization_audit_task_id_seq'::regclass);


--
-- Name: epics id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.epics ALTER COLUMN id SET DEFAULT nextval('public.epics_id_seq'::regclass);


--
-- Name: event_outbox id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_outbox ALTER COLUMN id SET DEFAULT nextval('public.event_outbox_id_seq'::regclass);


--
-- Name: field_labels id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.field_labels ALTER COLUMN id SET DEFAULT nextval('public.field_labels_id_seq'::regclass);


--
-- Name: idempotency_records id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idempotency_records ALTER COLUMN id SET DEFAULT nextval('public.idempotency_records_id_seq'::regclass);


--
-- Name: issue_tags id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_tags ALTER COLUMN id SET DEFAULT nextval('public.issue_tags_id_seq'::regclass);


--
-- Name: kr_comments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_comments ALTER COLUMN id SET DEFAULT nextval('public.kr_comments_id_seq'::regclass);


--
-- Name: kr_files id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_files ALTER COLUMN id SET DEFAULT nextval('public.kr_files_id_seq'::regclass);


--
-- Name: kr_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_history ALTER COLUMN id SET DEFAULT nextval('public.kr_history_id_seq'::regclass);


--
-- Name: kr_links id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_links ALTER COLUMN id SET DEFAULT nextval('public.kr_links_id_seq'::regclass);


--
-- Name: kr_measurements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_measurements ALTER COLUMN id SET DEFAULT nextval('public.kr_measurements_id_seq'::regclass);


--
-- Name: kr_metrics id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_metrics ALTER COLUMN id SET DEFAULT nextval('public.kr_metrics_id_seq'::regclass);


--
-- Name: kr_pause_intervals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_pause_intervals ALTER COLUMN id SET DEFAULT nextval('public.kr_pause_intervals_id_seq'::regclass);


--
-- Name: kr_period_closure_revisions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_period_closure_revisions ALTER COLUMN id SET DEFAULT nextval('public.kr_period_closure_revisions_id_seq'::regclass);


--
-- Name: kr_period_fact_revisions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_period_fact_revisions ALTER COLUMN id SET DEFAULT nextval('public.kr_period_fact_revisions_id_seq'::regclass);


--
-- Name: kr_period_plan_revisions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_period_plan_revisions ALTER COLUMN id SET DEFAULT nextval('public.kr_period_plan_revisions_id_seq'::regclass);


--
-- Name: kr_periods id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_periods ALTER COLUMN id SET DEFAULT nextval('public.kr_periods_id_seq'::regclass);


--
-- Name: kr_reporting_statuses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_reporting_statuses ALTER COLUMN id SET DEFAULT nextval('public.kr_reporting_statuses_id_seq'::regclass);


--
-- Name: kr_year_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_year_settings ALTER COLUMN id SET DEFAULT nextval('public.kr_year_settings_id_seq'::regclass);


--
-- Name: major_external_links id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.major_external_links ALTER COLUMN id SET DEFAULT nextval('public.major_external_links_id_seq'::regclass);


--
-- Name: meeting_actions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_actions ALTER COLUMN id SET DEFAULT nextval('public.meeting_actions_id_seq'::regclass);


--
-- Name: notification_templates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_templates ALTER COLUMN id SET DEFAULT nextval('public.notification_templates_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: priorities id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.priorities ALTER COLUMN id SET DEFAULT nextval('public.priorities_id_seq'::regclass);


--
-- Name: project_statuses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_statuses ALTER COLUMN id SET DEFAULT nextval('public.project_statuses_id_seq'::regclass);


--
-- Name: project_tags id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_tags ALTER COLUMN id SET DEFAULT nextval('public.project_tags_id_seq'::regclass);


--
-- Name: projects id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects ALTER COLUMN id SET DEFAULT nextval('public.projects_id_seq'::regclass);


--
-- Name: refresh_sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_sessions ALTER COLUMN id SET DEFAULT nextval('public.refresh_sessions_id_seq'::regclass);


--
-- Name: reporting_meeting_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporting_meeting_history ALTER COLUMN id SET DEFAULT nextval('public.reporting_meeting_history_id_seq'::regclass);


--
-- Name: reporting_meetings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporting_meetings ALTER COLUMN id SET DEFAULT nextval('public.reporting_meetings_id_seq'::regclass);


--
-- Name: reports id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reports ALTER COLUMN id SET DEFAULT nextval('public.reports_id_seq'::regclass);


--
-- Name: request_work_links id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_work_links ALTER COLUMN id SET DEFAULT nextval('public.request_work_links_id_seq'::regclass);


--
-- Name: requirement_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.requirement_requests ALTER COLUMN id SET DEFAULT nextval('public.requirement_requests_id_seq'::regclass);


--
-- Name: requirement_reviews id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.requirement_reviews ALTER COLUMN id SET DEFAULT nextval('public.requirement_reviews_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: security_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_events ALTER COLUMN id SET DEFAULT nextval('public.security_events_id_seq'::regclass);


--
-- Name: start_shifts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.start_shifts ALTER COLUMN id SET DEFAULT nextval('public.start_shifts_id_seq'::regclass);


--
-- Name: statuses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.statuses ALTER COLUMN id SET DEFAULT nextval('public.statuses_id_seq'::regclass);


--
-- Name: stories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stories ALTER COLUMN id SET DEFAULT nextval('public.stories_id_seq'::regclass);


--
-- Name: tags id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags ALTER COLUMN id SET DEFAULT nextval('public.tags_id_seq'::regclass);


--
-- Name: task_attachments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_attachments ALTER COLUMN id SET DEFAULT nextval('public.task_attachments_id_seq'::regclass);


--
-- Name: task_comments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_comments ALTER COLUMN id SET DEFAULT nextval('public.task_comments_id_seq'::regclass);


--
-- Name: task_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_history ALTER COLUMN id SET DEFAULT nextval('public.task_history_id_seq'::regclass);


--
-- Name: task_jira_links id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_jira_links ALTER COLUMN id SET DEFAULT nextval('public.task_jira_links_id_seq'::regclass);


--
-- Name: task_reporting_status_revisions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_reporting_status_revisions ALTER COLUMN id SET DEFAULT nextval('public.task_reporting_status_revisions_id_seq'::regclass);


--
-- Name: task_reporting_statuses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_reporting_statuses ALTER COLUMN id SET DEFAULT nextval('public.task_reporting_statuses_id_seq'::regclass);


--
-- Name: task_types id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_types ALTER COLUMN id SET DEFAULT nextval('public.task_types_id_seq'::regclass);


--
-- Name: task_viewers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_viewers ALTER COLUMN id SET DEFAULT nextval('public.task_viewers_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Name: team_competency_resources id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_competency_resources ALTER COLUMN id SET DEFAULT nextval('public.team_competency_resources_id_seq'::regclass);


--
-- Name: team_types id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_types ALTER COLUMN id SET DEFAULT nextval('public.team_types_id_seq'::regclass);


--
-- Name: teams id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teams ALTER COLUMN id SET DEFAULT nextval('public.teams_id_seq'::regclass);


--
-- Name: timeline_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timeline_events ALTER COLUMN id SET DEFAULT nextval('public.timeline_events_id_seq'::regclass);


--
-- Name: user_notification_preferences id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_notification_preferences ALTER COLUMN id SET DEFAULT nextval('public.user_notification_preferences_id_seq'::regclass);


--
-- Name: user_report_prefs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_report_prefs ALTER COLUMN id SET DEFAULT nextval('public.user_report_prefs_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: work_attachments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_attachments ALTER COLUMN id SET DEFAULT nextval('public.work_attachments_id_seq'::regclass);


--
-- Name: work_comments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_comments ALTER COLUMN id SET DEFAULT nextval('public.work_comments_id_seq'::regclass);


--
-- Name: work_dependencies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_dependencies ALTER COLUMN id SET DEFAULT nextval('public.work_dependencies_id_seq'::regclass);


--
-- Name: work_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_history ALTER COLUMN id SET DEFAULT nextval('public.work_history_id_seq'::regclass);


--
-- Name: work_resolutions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_resolutions ALTER COLUMN id SET DEFAULT nextval('public.work_resolutions_id_seq'::regclass);


--
-- Name: work_task_templates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_task_templates ALTER COLUMN id SET DEFAULT nextval('public.work_task_templates_id_seq'::regclass);


--
-- Name: work_tasks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_tasks ALTER COLUMN id SET DEFAULT nextval('public.work_tasks_id_seq'::regclass);


--
-- Name: agent_sessions agent_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_sessions
    ADD CONSTRAINT agent_sessions_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: auth_challenges auth_challenges_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_challenges
    ADD CONSTRAINT auth_challenges_pkey PRIMARY KEY (id);


--
-- Name: auth_challenges auth_challenges_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_challenges
    ADD CONSTRAINT auth_challenges_token_hash_key UNIQUE (token_hash);


--
-- Name: auth_sessions auth_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_sessions
    ADD CONSTRAINT auth_sessions_pkey PRIMARY KEY (id);


--
-- Name: backlog_assistant_integration backlog_assistant_integration_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backlog_assistant_integration
    ADD CONSTRAINT backlog_assistant_integration_pkey PRIMARY KEY (id);


--
-- Name: business_customers business_customers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.business_customers
    ADD CONSTRAINT business_customers_pkey PRIMARY KEY (id);


--
-- Name: channels channels_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channels
    ADD CONSTRAINT channels_code_key UNIQUE (code);


--
-- Name: channels channels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channels
    ADD CONSTRAINT channels_pkey PRIMARY KEY (id);


--
-- Name: column_labels column_labels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.column_labels
    ADD CONSTRAINT column_labels_pkey PRIMARY KEY (id);


--
-- Name: competency_cost_history competency_cost_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.competency_cost_history
    ADD CONSTRAINT competency_cost_history_pkey PRIMARY KEY (id);


--
-- Name: deadlines deadlines_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deadlines
    ADD CONSTRAINT deadlines_code_key UNIQUE (code);


--
-- Name: deadlines deadlines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deadlines
    ADD CONSTRAINT deadlines_pkey PRIMARY KEY (id);


--
-- Name: departments departments_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_code_key UNIQUE (code);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: dictionary_items dictionary_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dictionary_items
    ADD CONSTRAINT dictionary_items_pkey PRIMARY KEY (id);


--
-- Name: did_client_groups did_client_groups_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.did_client_groups
    ADD CONSTRAINT did_client_groups_code_key UNIQUE (code);


--
-- Name: did_client_groups did_client_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.did_client_groups
    ADD CONSTRAINT did_client_groups_pkey PRIMARY KEY (id);


--
-- Name: display_settings display_settings_page_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.display_settings
    ADD CONSTRAINT display_settings_page_key UNIQUE (page);


--
-- Name: display_settings display_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.display_settings
    ADD CONSTRAINT display_settings_pkey PRIMARY KEY (id);


--
-- Name: effort_rub_normalization_audit effort_rub_normalization_audit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.effort_rub_normalization_audit
    ADD CONSTRAINT effort_rub_normalization_audit_pkey PRIMARY KEY (task_id);


--
-- Name: epics epics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.epics
    ADD CONSTRAINT epics_pkey PRIMARY KEY (id);


--
-- Name: event_outbox event_outbox_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_outbox
    ADD CONSTRAINT event_outbox_pkey PRIMARY KEY (id);


--
-- Name: field_labels field_labels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.field_labels
    ADD CONSTRAINT field_labels_pkey PRIMARY KEY (id);


--
-- Name: idempotency_records idempotency_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idempotency_records
    ADD CONSTRAINT idempotency_records_pkey PRIMARY KEY (id);


--
-- Name: issue_tags issue_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_tags
    ADD CONSTRAINT issue_tags_pkey PRIMARY KEY (id);


--
-- Name: kr_comments kr_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_comments
    ADD CONSTRAINT kr_comments_pkey PRIMARY KEY (id);


--
-- Name: kr_files kr_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_files
    ADD CONSTRAINT kr_files_pkey PRIMARY KEY (id);


--
-- Name: kr_files kr_files_storage_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_files
    ADD CONSTRAINT kr_files_storage_key_key UNIQUE (storage_key);


--
-- Name: kr_history kr_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_history
    ADD CONSTRAINT kr_history_pkey PRIMARY KEY (id);


--
-- Name: kr_links kr_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_links
    ADD CONSTRAINT kr_links_pkey PRIMARY KEY (id);


--
-- Name: kr_measurements kr_measurements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_measurements
    ADD CONSTRAINT kr_measurements_pkey PRIMARY KEY (id);


--
-- Name: kr_metrics kr_metrics_legacy_task_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_metrics
    ADD CONSTRAINT kr_metrics_legacy_task_id_key UNIQUE (legacy_task_id);


--
-- Name: kr_metrics kr_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_metrics
    ADD CONSTRAINT kr_metrics_pkey PRIMARY KEY (id);


--
-- Name: kr_pause_intervals kr_pause_intervals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_pause_intervals
    ADD CONSTRAINT kr_pause_intervals_pkey PRIMARY KEY (id);


--
-- Name: kr_period_closure_revisions kr_period_closure_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_period_closure_revisions
    ADD CONSTRAINT kr_period_closure_revisions_pkey PRIMARY KEY (id);


--
-- Name: kr_period_fact_revisions kr_period_fact_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_period_fact_revisions
    ADD CONSTRAINT kr_period_fact_revisions_pkey PRIMARY KEY (id);


--
-- Name: kr_period_plan_revisions kr_period_plan_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_period_plan_revisions
    ADD CONSTRAINT kr_period_plan_revisions_pkey PRIMARY KEY (id);


--
-- Name: kr_periods kr_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_periods
    ADD CONSTRAINT kr_periods_pkey PRIMARY KEY (id);


--
-- Name: kr_reporting_statuses kr_reporting_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_reporting_statuses
    ADD CONSTRAINT kr_reporting_statuses_pkey PRIMARY KEY (id);


--
-- Name: kr_year_settings kr_year_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_year_settings
    ADD CONSTRAINT kr_year_settings_pkey PRIMARY KEY (id);


--
-- Name: login_reservations login_reservations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_reservations
    ADD CONSTRAINT login_reservations_pkey PRIMARY KEY (login_normalized);


--
-- Name: major_external_links major_external_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.major_external_links
    ADD CONSTRAINT major_external_links_pkey PRIMARY KEY (id);


--
-- Name: meeting_actions meeting_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_actions
    ADD CONSTRAINT meeting_actions_pkey PRIMARY KEY (id);


--
-- Name: meeting_application_receipts meeting_application_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_application_receipts
    ADD CONSTRAINT meeting_application_receipts_pkey PRIMARY KEY (service_run_id);


--
-- Name: meeting_captures meeting_captures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_captures
    ADD CONSTRAINT meeting_captures_pkey PRIMARY KEY (id);


--
-- Name: meeting_delivery_intents meeting_delivery_intents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_delivery_intents
    ADD CONSTRAINT meeting_delivery_intents_pkey PRIMARY KEY (operation_id);


--
-- Name: notification_templates notification_templates_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT notification_templates_name_key UNIQUE (name);


--
-- Name: notification_templates notification_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT notification_templates_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: priorities priorities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.priorities
    ADD CONSTRAINT priorities_pkey PRIMARY KEY (id);


--
-- Name: project_statuses project_statuses_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_statuses
    ADD CONSTRAINT project_statuses_code_key UNIQUE (code);


--
-- Name: project_statuses project_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_statuses
    ADD CONSTRAINT project_statuses_pkey PRIMARY KEY (id);


--
-- Name: project_tags project_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_tags
    ADD CONSTRAINT project_tags_pkey PRIMARY KEY (id);


--
-- Name: project_task_plans project_task_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_plans
    ADD CONSTRAINT project_task_plans_pkey PRIMARY KEY (task_id);


--
-- Name: projects projects_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_code_key UNIQUE (code);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: refresh_sessions refresh_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_sessions
    ADD CONSTRAINT refresh_sessions_pkey PRIMARY KEY (id);


--
-- Name: reporting_meeting_history reporting_meeting_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporting_meeting_history
    ADD CONSTRAINT reporting_meeting_history_pkey PRIMARY KEY (id);


--
-- Name: reporting_meetings reporting_meetings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporting_meetings
    ADD CONSTRAINT reporting_meetings_pkey PRIMARY KEY (id);


--
-- Name: reports reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_pkey PRIMARY KEY (id);


--
-- Name: request_work_links request_work_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_work_links
    ADD CONSTRAINT request_work_links_pkey PRIMARY KEY (id);


--
-- Name: requirement_requests requirement_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.requirement_requests
    ADD CONSTRAINT requirement_requests_pkey PRIMARY KEY (id);


--
-- Name: requirement_reviews requirement_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.requirement_reviews
    ADD CONSTRAINT requirement_reviews_pkey PRIMARY KEY (id);


--
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: security_events security_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_events
    ADD CONSTRAINT security_events_pkey PRIMARY KEY (id);


--
-- Name: start_shifts start_shifts_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.start_shifts
    ADD CONSTRAINT start_shifts_code_key UNIQUE (code);


--
-- Name: start_shifts start_shifts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.start_shifts
    ADD CONSTRAINT start_shifts_pkey PRIMARY KEY (id);


--
-- Name: statuses statuses_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.statuses
    ADD CONSTRAINT statuses_code_key UNIQUE (code);


--
-- Name: statuses statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.statuses
    ADD CONSTRAINT statuses_pkey PRIMARY KEY (id);


--
-- Name: stories stories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stories
    ADD CONSTRAINT stories_pkey PRIMARY KEY (id);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: task_attachments task_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_attachments
    ADD CONSTRAINT task_attachments_pkey PRIMARY KEY (id);


--
-- Name: task_comments task_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_comments
    ADD CONSTRAINT task_comments_pkey PRIMARY KEY (id);


--
-- Name: task_history task_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_history
    ADD CONSTRAINT task_history_pkey PRIMARY KEY (id);


--
-- Name: task_jira_links task_jira_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_jira_links
    ADD CONSTRAINT task_jira_links_pkey PRIMARY KEY (id);


--
-- Name: task_reporting_status_revisions task_reporting_status_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_reporting_status_revisions
    ADD CONSTRAINT task_reporting_status_revisions_pkey PRIMARY KEY (id);


--
-- Name: task_reporting_statuses task_reporting_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_reporting_statuses
    ADD CONSTRAINT task_reporting_statuses_pkey PRIMARY KEY (id);


--
-- Name: task_types task_types_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_types
    ADD CONSTRAINT task_types_code_key UNIQUE (code);


--
-- Name: task_types task_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_types
    ADD CONSTRAINT task_types_pkey PRIMARY KEY (id);


--
-- Name: task_viewers task_viewers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_viewers
    ADD CONSTRAINT task_viewers_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: team_competency_resources team_competency_resources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_competency_resources
    ADD CONSTRAINT team_competency_resources_pkey PRIMARY KEY (id);


--
-- Name: team_types team_types_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_types
    ADD CONSTRAINT team_types_code_key UNIQUE (code);


--
-- Name: team_types team_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_types
    ADD CONSTRAINT team_types_pkey PRIMARY KEY (id);


--
-- Name: teams teams_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_name_key UNIQUE (name);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (id);


--
-- Name: timeline_events timeline_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timeline_events
    ADD CONSTRAINT timeline_events_pkey PRIMARY KEY (id);


--
-- Name: competency_cost_history uq_competency_cost_history_competency_year; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.competency_cost_history
    ADD CONSTRAINT uq_competency_cost_history_competency_year UNIQUE (competency, year);


--
-- Name: idempotency_records uq_idempotency_operation_user_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idempotency_records
    ADD CONSTRAINT uq_idempotency_operation_user_key UNIQUE (operation, user_id, request_key);


--
-- Name: kr_period_fact_revisions uq_kr_fact_revision; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_period_fact_revisions
    ADD CONSTRAINT uq_kr_fact_revision UNIQUE (period_id, revision_no);


--
-- Name: kr_links uq_kr_link_task; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_links
    ADD CONSTRAINT uq_kr_link_task UNIQUE (metric_id, task_id);


--
-- Name: kr_links uq_kr_link_work; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_links
    ADD CONSTRAINT uq_kr_link_work UNIQUE (metric_id, work_task_id);


--
-- Name: kr_measurements uq_kr_measurement_date; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_measurements
    ADD CONSTRAINT uq_kr_measurement_date UNIQUE (period_id, measured_on);


--
-- Name: kr_periods uq_kr_period_dates; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_periods
    ADD CONSTRAINT uq_kr_period_dates UNIQUE (metric_id, start_date, end_date);


--
-- Name: kr_periods uq_kr_period_quarter; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_periods
    ADD CONSTRAINT uq_kr_period_quarter UNIQUE (metric_id, calendar_year, quarter);


--
-- Name: kr_period_plan_revisions uq_kr_plan_revision; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_period_plan_revisions
    ADD CONSTRAINT uq_kr_plan_revision UNIQUE (period_id, revision_no);


--
-- Name: kr_reporting_statuses uq_kr_reporting_period_meeting; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_reporting_statuses
    ADD CONSTRAINT uq_kr_reporting_period_meeting UNIQUE (period_id, meeting_id);


--
-- Name: kr_year_settings uq_kr_year_settings; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_year_settings
    ADD CONSTRAINT uq_kr_year_settings UNIQUE (metric_id, year);


--
-- Name: major_external_links uq_major_external_url; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.major_external_links
    ADD CONSTRAINT uq_major_external_url UNIQUE (major_task_id, url);


--
-- Name: meeting_actions uq_meeting_action_item; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_actions
    ADD CONSTRAINT uq_meeting_action_item UNIQUE (capture_id, item_id);


--
-- Name: reporting_meetings uq_reporting_meeting_occurrence; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporting_meetings
    ADD CONSTRAINT uq_reporting_meeting_occurrence UNIQUE (kind, occurrence_key);


--
-- Name: request_work_links uq_request_major_link; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_work_links
    ADD CONSTRAINT uq_request_major_link UNIQUE (request_id, major_task_id);


--
-- Name: request_work_links uq_request_work_link; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_work_links
    ADD CONSTRAINT uq_request_work_link UNIQUE (request_id, work_task_id);


--
-- Name: requirement_requests uq_requirement_request_session_active; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.requirement_requests
    ADD CONSTRAINT uq_requirement_request_session_active UNIQUE (agent_session_id, is_deleted);


--
-- Name: requirement_reviews uq_requirement_review_active_artifact; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.requirement_reviews
    ADD CONSTRAINT uq_requirement_review_active_artifact UNIQUE (active_artifact_id);


--
-- Name: requirement_reviews uq_requirement_review_submission_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.requirement_reviews
    ADD CONSTRAINT uq_requirement_review_submission_key UNIQUE (creator_id, idempotency_key);


--
-- Name: task_jira_links uq_task_jira_links_task_url; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_jira_links
    ADD CONSTRAINT uq_task_jira_links_task_url UNIQUE (task_id, url);


--
-- Name: task_reporting_statuses uq_task_reporting_status_meeting_task; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_reporting_statuses
    ADD CONSTRAINT uq_task_reporting_status_meeting_task UNIQUE (meeting_id, task_id);


--
-- Name: user_report_prefs uq_user_report_prefs; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_report_prefs
    ADD CONSTRAINT uq_user_report_prefs UNIQUE (user_id, report_key);


--
-- Name: users uq_users_login_normalized; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT uq_users_login_normalized UNIQUE (login_normalized);


--
-- Name: user_notification_preferences user_notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_notification_preferences
    ADD CONSTRAINT user_notification_preferences_pkey PRIMARY KEY (id);


--
-- Name: user_notification_preferences user_notification_preferences_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_notification_preferences
    ADD CONSTRAINT user_notification_preferences_user_id_key UNIQUE (user_id);


--
-- Name: user_report_prefs user_report_prefs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_report_prefs
    ADD CONSTRAINT user_report_prefs_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: work_attachments work_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_attachments
    ADD CONSTRAINT work_attachments_pkey PRIMARY KEY (id);


--
-- Name: work_attachments work_attachments_storage_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_attachments
    ADD CONSTRAINT work_attachments_storage_key_key UNIQUE (storage_key);


--
-- Name: work_comments work_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_comments
    ADD CONSTRAINT work_comments_pkey PRIMARY KEY (id);


--
-- Name: work_dependencies work_dependencies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_dependencies
    ADD CONSTRAINT work_dependencies_pkey PRIMARY KEY (id);


--
-- Name: work_history work_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_history
    ADD CONSTRAINT work_history_pkey PRIMARY KEY (id);


--
-- Name: work_meeting_snapshots work_meeting_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_meeting_snapshots
    ADD CONSTRAINT work_meeting_snapshots_pkey PRIMARY KEY (meeting_id);


--
-- Name: work_resolutions work_resolutions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_resolutions
    ADD CONSTRAINT work_resolutions_pkey PRIMARY KEY (id);


--
-- Name: work_resolutions work_resolutions_request_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_resolutions
    ADD CONSTRAINT work_resolutions_request_id_key UNIQUE (request_id);


--
-- Name: work_task_templates work_task_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_task_templates
    ADD CONSTRAINT work_task_templates_pkey PRIMARY KEY (id);


--
-- Name: work_tasks work_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_tasks
    ADD CONSTRAINT work_tasks_pkey PRIMARY KEY (id);


--
-- Name: ix_agent_sessions_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_sessions_id ON public.agent_sessions USING btree (id);


--
-- Name: ix_agent_sessions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_agent_sessions_user_id ON public.agent_sessions USING btree (user_id);


--
-- Name: ix_audit_log_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_log_id ON public.audit_log USING btree (id);


--
-- Name: ix_audit_log_request_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_log_request_id ON public.audit_log USING btree (request_id);


--
-- Name: ix_audit_log_trace_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_log_trace_id ON public.audit_log USING btree (trace_id);


--
-- Name: ix_auth_challenges_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_auth_challenges_user_id ON public.auth_challenges USING btree (user_id);


--
-- Name: ix_auth_sessions_revoked_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_auth_sessions_revoked_at ON public.auth_sessions USING btree (revoked_at);


--
-- Name: ix_auth_sessions_user_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_auth_sessions_user_expiry ON public.auth_sessions USING btree (user_id, revoked_at, absolute_expires_at);


--
-- Name: ix_auth_sessions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_auth_sessions_user_id ON public.auth_sessions USING btree (user_id);


--
-- Name: ix_backlog_assistant_integration_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_backlog_assistant_integration_expires ON public.backlog_assistant_integration USING btree (expires);


--
-- Name: ix_backlog_assistant_integration_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_backlog_assistant_integration_kind ON public.backlog_assistant_integration USING btree (kind);


--
-- Name: ix_backlog_assistant_integration_subject; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_backlog_assistant_integration_subject ON public.backlog_assistant_integration USING btree (subject);


--
-- Name: ix_business_customers_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_business_customers_id ON public.business_customers USING btree (id);


--
-- Name: ix_channels_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channels_id ON public.channels USING btree (id);


--
-- Name: ix_column_labels_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_column_labels_id ON public.column_labels USING btree (id);


--
-- Name: ix_column_labels_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_column_labels_key ON public.column_labels USING btree (key);


--
-- Name: ix_competency_cost_history_competency; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_competency_cost_history_competency ON public.competency_cost_history USING btree (competency);


--
-- Name: ix_competency_cost_history_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_competency_cost_history_id ON public.competency_cost_history USING btree (id);


--
-- Name: ix_competency_cost_history_year; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_competency_cost_history_year ON public.competency_cost_history USING btree (year);


--
-- Name: ix_deadlines_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_deadlines_id ON public.deadlines USING btree (id);


--
-- Name: ix_departments_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_departments_id ON public.departments USING btree (id);


--
-- Name: ix_dictionary_items_dict_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_dictionary_items_dict_type ON public.dictionary_items USING btree (dict_type);


--
-- Name: ix_dictionary_items_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_dictionary_items_id ON public.dictionary_items USING btree (id);


--
-- Name: ix_display_settings_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_display_settings_id ON public.display_settings USING btree (id);


--
-- Name: ix_epics_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_epics_id ON public.epics USING btree (id);


--
-- Name: ix_epics_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_epics_task_id ON public.epics USING btree (task_id);


--
-- Name: ix_event_outbox_aggregate_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_outbox_aggregate_id ON public.event_outbox USING btree (aggregate_id);


--
-- Name: ix_event_outbox_audience_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_outbox_audience_user_id ON public.event_outbox USING btree (audience_user_id);


--
-- Name: ix_event_outbox_claim; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_outbox_claim ON public.event_outbox USING btree (claim_token, claimed_at);


--
-- Name: ix_event_outbox_dead_lettered_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_outbox_dead_lettered_at ON public.event_outbox USING btree (dead_lettered_at);


--
-- Name: ix_event_outbox_event_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_outbox_event_type ON public.event_outbox USING btree (event_type);


--
-- Name: ix_event_outbox_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_outbox_pending ON public.event_outbox USING btree (processed_at, available_at, id);


--
-- Name: ix_field_labels_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_field_labels_id ON public.field_labels USING btree (id);


--
-- Name: ix_field_labels_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_field_labels_key ON public.field_labels USING btree (key);


--
-- Name: ix_idempotency_records_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_idempotency_records_created_at ON public.idempotency_records USING btree (created_at);


--
-- Name: ix_issue_tags_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_issue_tags_id ON public.issue_tags USING btree (id);


--
-- Name: ix_kr_comments_metric_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_kr_comments_metric_id ON public.kr_comments USING btree (metric_id);


--
-- Name: ix_kr_comments_period_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_kr_comments_period_id ON public.kr_comments USING btree (period_id);


--
-- Name: ix_kr_files_measurement_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_kr_files_measurement_id ON public.kr_files USING btree (measurement_id);


--
-- Name: ix_kr_files_metric_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_kr_files_metric_id ON public.kr_files USING btree (metric_id);


--
-- Name: ix_kr_files_period_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_kr_files_period_id ON public.kr_files USING btree (period_id);


--
-- Name: ix_kr_history_metric_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_kr_history_metric_created ON public.kr_history USING btree (metric_id, created_at, id);


--
-- Name: ix_kr_history_metric_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_kr_history_metric_id ON public.kr_history USING btree (metric_id);


--
-- Name: ix_kr_links_metric_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_kr_links_metric_id ON public.kr_links USING btree (metric_id);


--
-- Name: ix_kr_measurements_period_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_kr_measurements_period_id ON public.kr_measurements USING btree (period_id);


--
-- Name: ix_kr_metrics_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_kr_metrics_project_id ON public.kr_metrics USING btree (project_id);


--
-- Name: ix_kr_metrics_team_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_kr_metrics_team_id ON public.kr_metrics USING btree (team_id);


--
-- Name: ix_kr_pause_intervals_metric_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_kr_pause_intervals_metric_id ON public.kr_pause_intervals USING btree (metric_id);


--
-- Name: ix_kr_period_closure_revisions_fact_revision_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_kr_period_closure_revisions_fact_revision_id ON public.kr_period_closure_revisions USING btree (fact_revision_id);


--
-- Name: ix_kr_period_closure_revisions_period_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_kr_period_closure_revisions_period_id ON public.kr_period_closure_revisions USING btree (period_id);


--
-- Name: ix_kr_period_closure_revisions_plan_revision_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_kr_period_closure_revisions_plan_revision_id ON public.kr_period_closure_revisions USING btree (plan_revision_id);


--
-- Name: ix_kr_period_closure_revisions_previous_revision_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_kr_period_closure_revisions_previous_revision_id ON public.kr_period_closure_revisions USING btree (previous_revision_id);


--
-- Name: ix_kr_period_fact_revisions_previous_revision_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_kr_period_fact_revisions_previous_revision_id ON public.kr_period_fact_revisions USING btree (previous_revision_id);


--
-- Name: ix_kr_period_fact_revisions_source_measurement_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_kr_period_fact_revisions_source_measurement_id ON public.kr_period_fact_revisions USING btree (source_measurement_id);


--
-- Name: ix_kr_period_plan_revisions_previous_revision_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_kr_period_plan_revisions_previous_revision_id ON public.kr_period_plan_revisions USING btree (previous_revision_id);


--
-- Name: ix_kr_periods_closure_revision_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_kr_periods_closure_revision_id ON public.kr_periods USING btree (closure_revision_id);


--
-- Name: ix_kr_periods_current_fact_revision_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_kr_periods_current_fact_revision_id ON public.kr_periods USING btree (current_fact_revision_id);


--
-- Name: ix_kr_periods_current_plan_revision_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_kr_periods_current_plan_revision_id ON public.kr_periods USING btree (current_plan_revision_id);


--
-- Name: ix_kr_periods_end_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_kr_periods_end_date ON public.kr_periods USING btree (end_date);


--
-- Name: ix_kr_periods_metric_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_kr_periods_metric_id ON public.kr_periods USING btree (metric_id);


--
-- Name: ix_kr_periods_start_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_kr_periods_start_date ON public.kr_periods USING btree (start_date);


--
-- Name: ix_kr_reporting_statuses_metric_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_kr_reporting_statuses_metric_id ON public.kr_reporting_statuses USING btree (metric_id);


--
-- Name: ix_major_external_links_major_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_major_external_links_major_task_id ON public.major_external_links USING btree (major_task_id);


--
-- Name: ix_meeting_actions_capture_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meeting_actions_capture_id ON public.meeting_actions USING btree (capture_id);


--
-- Name: ix_meeting_actions_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meeting_actions_task_id ON public.meeting_actions USING btree (task_id);


--
-- Name: ix_meeting_captures_analysis_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meeting_captures_analysis_status ON public.meeting_captures USING btree (analysis_status);


--
-- Name: ix_meeting_captures_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meeting_captures_owner_id ON public.meeting_captures USING btree (owner_id);


--
-- Name: ix_meeting_receipt_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meeting_receipt_pending ON public.meeting_application_receipts USING btree (ack_pending, updated_at);


--
-- Name: ix_notification_templates_event_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notification_templates_event_type ON public.notification_templates USING btree (event_type);


--
-- Name: ix_notification_templates_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notification_templates_id ON public.notification_templates USING btree (id);


--
-- Name: ix_notifications_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notifications_id ON public.notifications USING btree (id);


--
-- Name: ix_notifications_work_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notifications_work_task_id ON public.notifications USING btree (work_task_id);


--
-- Name: ix_priorities_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_priorities_id ON public.priorities USING btree (id);


--
-- Name: ix_project_statuses_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_project_statuses_id ON public.project_statuses USING btree (id);


--
-- Name: ix_project_tags_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_project_tags_id ON public.project_tags USING btree (id);


--
-- Name: ix_projects_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_projects_id ON public.projects USING btree (id);


--
-- Name: ix_refresh_sessions_auth_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_refresh_sessions_auth_session_id ON public.refresh_sessions USING btree (auth_session_id);


--
-- Name: ix_refresh_sessions_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_refresh_sessions_expires_at ON public.refresh_sessions USING btree (expires_at);


--
-- Name: ix_refresh_sessions_family_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_refresh_sessions_family_id ON public.refresh_sessions USING btree (family_id);


--
-- Name: ix_refresh_sessions_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_refresh_sessions_id ON public.refresh_sessions USING btree (id);


--
-- Name: ix_refresh_sessions_jti; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_refresh_sessions_jti ON public.refresh_sessions USING btree (jti);


--
-- Name: ix_refresh_sessions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_refresh_sessions_user_id ON public.refresh_sessions USING btree (user_id);


--
-- Name: ix_reporting_meeting_history_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_reporting_meeting_history_id ON public.reporting_meeting_history USING btree (id);


--
-- Name: ix_reporting_meeting_history_meeting_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_reporting_meeting_history_meeting_id ON public.reporting_meeting_history USING btree (meeting_id);


--
-- Name: ix_reporting_meetings_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_reporting_meetings_id ON public.reporting_meetings USING btree (id);


--
-- Name: ix_reporting_meetings_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_reporting_meetings_kind ON public.reporting_meetings USING btree (kind);


--
-- Name: ix_reporting_meetings_kind_state_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_reporting_meetings_kind_state_date ON public.reporting_meetings USING btree (kind, state, scheduled_date);


--
-- Name: ix_reporting_meetings_scheduled_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_reporting_meetings_scheduled_date ON public.reporting_meetings USING btree (scheduled_date);


--
-- Name: ix_reporting_meetings_state; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_reporting_meetings_state ON public.reporting_meetings USING btree (state);


--
-- Name: ix_reports_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_reports_id ON public.reports USING btree (id);


--
-- Name: ix_reports_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_reports_key ON public.reports USING btree (key);


--
-- Name: ix_request_work_links_major_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_request_work_links_major_task_id ON public.request_work_links USING btree (major_task_id);


--
-- Name: ix_request_work_links_request_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_request_work_links_request_id ON public.request_work_links USING btree (request_id);


--
-- Name: ix_request_work_links_work_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_request_work_links_work_task_id ON public.request_work_links USING btree (work_task_id);


--
-- Name: ix_requirement_requests_assignee_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_requirement_requests_assignee_id ON public.requirement_requests USING btree (assignee_id);


--
-- Name: ix_requirement_requests_coordinator_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_requirement_requests_coordinator_id ON public.requirement_requests USING btree (coordinator_id);


--
-- Name: ix_requirement_requests_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_requirement_requests_id ON public.requirement_requests USING btree (id);


--
-- Name: ix_requirement_requests_is_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_requirement_requests_is_deleted ON public.requirement_requests USING btree (is_deleted);


--
-- Name: ix_requirement_requests_next_action_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_requirement_requests_next_action_due ON public.requirement_requests USING btree (next_action_due);


--
-- Name: ix_requirement_requests_reviewer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_requirement_requests_reviewer_id ON public.requirement_requests USING btree (reviewer_id);


--
-- Name: ix_requirement_requests_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_requirement_requests_status ON public.requirement_requests USING btree (status);


--
-- Name: ix_requirement_requests_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_requirement_requests_task_id ON public.requirement_requests USING btree (task_id);


--
-- Name: ix_requirement_requests_team_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_requirement_requests_team_id ON public.requirement_requests USING btree (team_id);


--
-- Name: ix_requirement_requests_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_requirement_requests_user_id ON public.requirement_requests USING btree (user_id);


--
-- Name: ix_requirement_reviews_artifact_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_requirement_reviews_artifact_id ON public.requirement_reviews USING btree (artifact_id);


--
-- Name: ix_requirement_reviews_creator_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_requirement_reviews_creator_id ON public.requirement_reviews USING btree (creator_id);


--
-- Name: ix_requirement_reviews_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_requirement_reviews_id ON public.requirement_reviews USING btree (id);


--
-- Name: ix_requirement_reviews_reviewer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_requirement_reviews_reviewer_id ON public.requirement_reviews USING btree (reviewer_id);


--
-- Name: ix_requirement_reviews_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_requirement_reviews_status ON public.requirement_reviews USING btree (status);


--
-- Name: ix_requirement_reviews_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_requirement_reviews_target ON public.requirement_reviews USING btree (target_type, target_id);


--
-- Name: ix_requirement_reviews_team_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_requirement_reviews_team_id ON public.requirement_reviews USING btree (team_id);


--
-- Name: ix_roles_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_roles_id ON public.roles USING btree (id);


--
-- Name: ix_security_events_subject_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_security_events_subject_id ON public.security_events USING btree (subject_id);


--
-- Name: ix_security_events_subject_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_security_events_subject_time ON public.security_events USING btree (subject_id, created_at);


--
-- Name: ix_statuses_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_statuses_id ON public.statuses USING btree (id);


--
-- Name: ix_stories_epic_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stories_epic_id ON public.stories USING btree (epic_id);


--
-- Name: ix_stories_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stories_id ON public.stories USING btree (id);


--
-- Name: ix_tags_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tags_id ON public.tags USING btree (id);


--
-- Name: ix_task_attachments_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_task_attachments_id ON public.task_attachments USING btree (id);


--
-- Name: ix_task_attachments_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_task_attachments_task_id ON public.task_attachments USING btree (task_id);


--
-- Name: ix_task_comments_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_task_comments_id ON public.task_comments USING btree (id);


--
-- Name: ix_task_comments_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_task_comments_parent_id ON public.task_comments USING btree (parent_id);


--
-- Name: ix_task_comments_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_task_comments_task_id ON public.task_comments USING btree (task_id);


--
-- Name: ix_task_history_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_task_history_id ON public.task_history USING btree (id);


--
-- Name: ix_task_jira_links_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_task_jira_links_id ON public.task_jira_links USING btree (id);


--
-- Name: ix_task_jira_links_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_task_jira_links_task_id ON public.task_jira_links USING btree (task_id);


--
-- Name: ix_task_reporting_status_revisions_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_task_reporting_status_revisions_id ON public.task_reporting_status_revisions USING btree (id);


--
-- Name: ix_task_reporting_status_revisions_reporting_status_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_task_reporting_status_revisions_reporting_status_id ON public.task_reporting_status_revisions USING btree (reporting_status_id);


--
-- Name: ix_task_reporting_status_task_meeting; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_task_reporting_status_task_meeting ON public.task_reporting_statuses USING btree (task_id, meeting_id);


--
-- Name: ix_task_reporting_statuses_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_task_reporting_statuses_id ON public.task_reporting_statuses USING btree (id);


--
-- Name: ix_task_reporting_statuses_meeting_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_task_reporting_statuses_meeting_id ON public.task_reporting_statuses USING btree (meeting_id);


--
-- Name: ix_task_reporting_statuses_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_task_reporting_statuses_task_id ON public.task_reporting_statuses USING btree (task_id);


--
-- Name: ix_task_types_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_task_types_id ON public.task_types USING btree (id);


--
-- Name: ix_task_viewers_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_task_viewers_id ON public.task_viewers USING btree (id);


--
-- Name: ix_task_viewers_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_task_viewers_task_id ON public.task_viewers USING btree (task_id);


--
-- Name: ix_task_viewers_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_task_viewers_user_id ON public.task_viewers USING btree (user_id);


--
-- Name: ix_tasks_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tasks_id ON public.tasks USING btree (id);


--
-- Name: ix_tasks_is_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tasks_is_deleted ON public.tasks USING btree (is_deleted);


--
-- Name: ix_tasks_metric_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tasks_metric_id ON public.tasks USING btree (metric_id);


--
-- Name: ix_tasks_start_shift_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tasks_start_shift_id ON public.tasks USING btree (start_shift_id);


--
-- Name: ix_tasks_team_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tasks_team_id ON public.tasks USING btree (team_id);


--
-- Name: ix_team_competency_resources_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_team_competency_resources_id ON public.team_competency_resources USING btree (id);


--
-- Name: ix_team_competency_resources_team_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_team_competency_resources_team_id ON public.team_competency_resources USING btree (team_id);


--
-- Name: ix_team_types_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_team_types_id ON public.team_types USING btree (id);


--
-- Name: ix_teams_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_teams_id ON public.teams USING btree (id);


--
-- Name: ix_timeline_events_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_timeline_events_id ON public.timeline_events USING btree (id);


--
-- Name: ix_user_notification_preferences_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_notification_preferences_id ON public.user_notification_preferences USING btree (id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_work_attachments_work_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_work_attachments_work_task_id ON public.work_attachments USING btree (work_task_id);


--
-- Name: ix_work_comments_work_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_work_comments_work_task_id ON public.work_comments USING btree (work_task_id);


--
-- Name: ix_work_history_work_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_work_history_work_task_id ON public.work_history USING btree (work_task_id);


--
-- Name: ix_work_task_templates_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_work_task_templates_owner_id ON public.work_task_templates USING btree (owner_id);


--
-- Name: ix_work_tasks_acceptor_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_work_tasks_acceptor_id ON public.work_tasks USING btree (acceptor_id);


--
-- Name: ix_work_tasks_assignee_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_work_tasks_assignee_id ON public.work_tasks USING btree (assignee_id);


--
-- Name: ix_work_tasks_direct_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_work_tasks_direct_project_id ON public.work_tasks USING btree (direct_project_id);


--
-- Name: ix_work_tasks_due_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_work_tasks_due_date ON public.work_tasks USING btree (due_date);


--
-- Name: ix_work_tasks_execution_team_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_work_tasks_execution_team_id ON public.work_tasks USING btree (execution_team_id);


--
-- Name: ix_work_tasks_major_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_work_tasks_major_task_id ON public.work_tasks USING btree (major_task_id);


--
-- Name: ix_work_tasks_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_work_tasks_priority ON public.work_tasks USING btree (priority);


--
-- Name: ix_work_tasks_requester_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_work_tasks_requester_id ON public.work_tasks USING btree (requester_id);


--
-- Name: ix_work_tasks_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_work_tasks_status ON public.work_tasks USING btree (status);


--
-- Name: uq_active_password_setup; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_active_password_setup ON public.auth_challenges USING btree (user_id) WHERE (((purpose)::text = ANY ((ARRAY['invitation'::character varying, 'recovery'::character varying])::text[])) AND (used_at IS NULL) AND (revoked_at IS NULL));


--
-- Name: uq_dictionary_reference; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_dictionary_reference ON public.dictionary_items USING btree (dict_type, reference_id);


--
-- Name: ux_task_viewers_task_user; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_task_viewers_task_user ON public.task_viewers USING btree (task_id, user_id);


--
-- Name: ux_tasks_public_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_tasks_public_id ON public.tasks USING btree (public_id);


--
-- Name: tasks preserve_work_relations; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER preserve_work_relations BEFORE DELETE ON public.tasks FOR EACH ROW EXECUTE FUNCTION public.preserve_work_relations_on_task_delete();


--
-- Name: work_meeting_snapshots work_snapshot_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER work_snapshot_immutable BEFORE DELETE OR UPDATE ON public.work_meeting_snapshots FOR EACH ROW EXECUTE FUNCTION public.prevent_work_snapshot_mutation();


--
-- Name: agent_sessions agent_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_sessions
    ADD CONSTRAINT agent_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: audit_log audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: auth_challenges auth_challenges_issuer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_challenges
    ADD CONSTRAINT auth_challenges_issuer_id_fkey FOREIGN KEY (issuer_id) REFERENCES public.users(id);


--
-- Name: auth_challenges auth_challenges_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_challenges
    ADD CONSTRAINT auth_challenges_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.auth_sessions(id);


--
-- Name: auth_challenges auth_challenges_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_challenges
    ADD CONSTRAINT auth_challenges_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: auth_sessions auth_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_sessions
    ADD CONSTRAINT auth_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: dictionary_items dictionary_items_lock_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dictionary_items
    ADD CONSTRAINT dictionary_items_lock_owner_id_fkey FOREIGN KEY (lock_owner_id) REFERENCES public.users(id);


--
-- Name: epics epics_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.epics
    ADD CONSTRAINT epics_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id);


--
-- Name: business_customers fk_business_customers_department_id_departments; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.business_customers
    ADD CONSTRAINT fk_business_customers_department_id_departments FOREIGN KEY (department_id) REFERENCES public.departments(id);


--
-- Name: departments fk_departments_lock_owner_id_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT fk_departments_lock_owner_id_users FOREIGN KEY (lock_owner_id) REFERENCES public.users(id);


--
-- Name: kr_periods fk_kr_period_closure_revision_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_periods
    ADD CONSTRAINT fk_kr_period_closure_revision_id FOREIGN KEY (closure_revision_id) REFERENCES public.kr_period_closure_revisions(id);


--
-- Name: kr_periods fk_kr_period_current_fact_revision_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_periods
    ADD CONSTRAINT fk_kr_period_current_fact_revision_id FOREIGN KEY (current_fact_revision_id) REFERENCES public.kr_period_fact_revisions(id);


--
-- Name: kr_periods fk_kr_period_current_plan_revision_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_periods
    ADD CONSTRAINT fk_kr_period_current_plan_revision_id FOREIGN KEY (current_plan_revision_id) REFERENCES public.kr_period_plan_revisions(id);


--
-- Name: refresh_sessions fk_refresh_auth_session; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_sessions
    ADD CONSTRAINT fk_refresh_auth_session FOREIGN KEY (auth_session_id) REFERENCES public.auth_sessions(id);


--
-- Name: tasks fk_tasks_did_client_group; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT fk_tasks_did_client_group FOREIGN KEY (did_client_group_id) REFERENCES public.did_client_groups(id);


--
-- Name: tasks fk_tasks_metric_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT fk_tasks_metric_id FOREIGN KEY (metric_id) REFERENCES public.kr_metrics(id);


--
-- Name: tasks fk_tasks_start_shift; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT fk_tasks_start_shift FOREIGN KEY (start_shift_id) REFERENCES public.start_shifts(id);


--
-- Name: teams fk_teams_cl_id_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT fk_teams_cl_id_users FOREIGN KEY (cl_id) REFERENCES public.users(id);


--
-- Name: teams fk_teams_it_pl_id_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT fk_teams_it_pl_id_users FOREIGN KEY (it_pl_id) REFERENCES public.users(id);


--
-- Name: teams fk_teams_pl_id_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT fk_teams_pl_id_users FOREIGN KEY (pl_id) REFERENCES public.users(id);


--
-- Name: teams fk_teams_po_id_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT fk_teams_po_id_users FOREIGN KEY (po_id) REFERENCES public.users(id);


--
-- Name: issue_tags issue_tags_issue_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_tags
    ADD CONSTRAINT issue_tags_issue_id_fkey FOREIGN KEY (issue_id) REFERENCES public.tasks(id);


--
-- Name: issue_tags issue_tags_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_tags
    ADD CONSTRAINT issue_tags_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES public.tags(id);


--
-- Name: kr_comments kr_comments_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_comments
    ADD CONSTRAINT kr_comments_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: kr_comments kr_comments_metric_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_comments
    ADD CONSTRAINT kr_comments_metric_id_fkey FOREIGN KEY (metric_id) REFERENCES public.kr_metrics(id);


--
-- Name: kr_comments kr_comments_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_comments
    ADD CONSTRAINT kr_comments_period_id_fkey FOREIGN KEY (period_id) REFERENCES public.kr_periods(id);


--
-- Name: kr_files kr_files_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_files
    ADD CONSTRAINT kr_files_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: kr_files kr_files_measurement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_files
    ADD CONSTRAINT kr_files_measurement_id_fkey FOREIGN KEY (measurement_id) REFERENCES public.kr_measurements(id);


--
-- Name: kr_files kr_files_metric_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_files
    ADD CONSTRAINT kr_files_metric_id_fkey FOREIGN KEY (metric_id) REFERENCES public.kr_metrics(id);


--
-- Name: kr_files kr_files_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_files
    ADD CONSTRAINT kr_files_period_id_fkey FOREIGN KEY (period_id) REFERENCES public.kr_periods(id);


--
-- Name: kr_history kr_history_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_history
    ADD CONSTRAINT kr_history_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id);


--
-- Name: kr_history kr_history_metric_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_history
    ADD CONSTRAINT kr_history_metric_id_fkey FOREIGN KEY (metric_id) REFERENCES public.kr_metrics(id);


--
-- Name: kr_history kr_history_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_history
    ADD CONSTRAINT kr_history_period_id_fkey FOREIGN KEY (period_id) REFERENCES public.kr_periods(id);


--
-- Name: kr_links kr_links_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_links
    ADD CONSTRAINT kr_links_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: kr_links kr_links_metric_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_links
    ADD CONSTRAINT kr_links_metric_id_fkey FOREIGN KEY (metric_id) REFERENCES public.kr_metrics(id);


--
-- Name: kr_links kr_links_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_links
    ADD CONSTRAINT kr_links_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id);


--
-- Name: kr_links kr_links_work_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_links
    ADD CONSTRAINT kr_links_work_task_id_fkey FOREIGN KEY (work_task_id) REFERENCES public.work_tasks(id);


--
-- Name: kr_measurements kr_measurements_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_measurements
    ADD CONSTRAINT kr_measurements_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: kr_measurements kr_measurements_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_measurements
    ADD CONSTRAINT kr_measurements_period_id_fkey FOREIGN KEY (period_id) REFERENCES public.kr_periods(id);


--
-- Name: kr_metrics kr_metrics_business_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_metrics
    ADD CONSTRAINT kr_metrics_business_customer_id_fkey FOREIGN KEY (business_customer_id) REFERENCES public.business_customers(id);


--
-- Name: kr_metrics kr_metrics_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_metrics
    ADD CONSTRAINT kr_metrics_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: kr_metrics kr_metrics_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_metrics
    ADD CONSTRAINT kr_metrics_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id);


--
-- Name: kr_metrics kr_metrics_did_client_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_metrics
    ADD CONSTRAINT kr_metrics_did_client_group_id_fkey FOREIGN KEY (did_client_group_id) REFERENCES public.did_client_groups(id);


--
-- Name: kr_metrics kr_metrics_legacy_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_metrics
    ADD CONSTRAINT kr_metrics_legacy_task_id_fkey FOREIGN KEY (legacy_task_id) REFERENCES public.tasks(id);


--
-- Name: kr_metrics kr_metrics_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_metrics
    ADD CONSTRAINT kr_metrics_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id);


--
-- Name: kr_metrics kr_metrics_priority_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_metrics
    ADD CONSTRAINT kr_metrics_priority_id_fkey FOREIGN KEY (priority_id) REFERENCES public.priorities(id);


--
-- Name: kr_metrics kr_metrics_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_metrics
    ADD CONSTRAINT kr_metrics_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: kr_metrics kr_metrics_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_metrics
    ADD CONSTRAINT kr_metrics_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id);


--
-- Name: kr_pause_intervals kr_pause_intervals_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_pause_intervals
    ADD CONSTRAINT kr_pause_intervals_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: kr_pause_intervals kr_pause_intervals_metric_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_pause_intervals
    ADD CONSTRAINT kr_pause_intervals_metric_id_fkey FOREIGN KEY (metric_id) REFERENCES public.kr_metrics(id);


--
-- Name: kr_period_closure_revisions kr_period_closure_revisions_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_period_closure_revisions
    ADD CONSTRAINT kr_period_closure_revisions_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: kr_period_closure_revisions kr_period_closure_revisions_fact_revision_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_period_closure_revisions
    ADD CONSTRAINT kr_period_closure_revisions_fact_revision_id_fkey FOREIGN KEY (fact_revision_id) REFERENCES public.kr_period_fact_revisions(id);


--
-- Name: kr_period_closure_revisions kr_period_closure_revisions_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_period_closure_revisions
    ADD CONSTRAINT kr_period_closure_revisions_period_id_fkey FOREIGN KEY (period_id) REFERENCES public.kr_periods(id);


--
-- Name: kr_period_closure_revisions kr_period_closure_revisions_plan_revision_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_period_closure_revisions
    ADD CONSTRAINT kr_period_closure_revisions_plan_revision_id_fkey FOREIGN KEY (plan_revision_id) REFERENCES public.kr_period_plan_revisions(id);


--
-- Name: kr_period_closure_revisions kr_period_closure_revisions_previous_revision_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_period_closure_revisions
    ADD CONSTRAINT kr_period_closure_revisions_previous_revision_id_fkey FOREIGN KEY (previous_revision_id) REFERENCES public.kr_period_closure_revisions(id);


--
-- Name: kr_period_fact_revisions kr_period_fact_revisions_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_period_fact_revisions
    ADD CONSTRAINT kr_period_fact_revisions_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: kr_period_fact_revisions kr_period_fact_revisions_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_period_fact_revisions
    ADD CONSTRAINT kr_period_fact_revisions_period_id_fkey FOREIGN KEY (period_id) REFERENCES public.kr_periods(id);


--
-- Name: kr_period_fact_revisions kr_period_fact_revisions_previous_revision_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_period_fact_revisions
    ADD CONSTRAINT kr_period_fact_revisions_previous_revision_id_fkey FOREIGN KEY (previous_revision_id) REFERENCES public.kr_period_fact_revisions(id);


--
-- Name: kr_period_fact_revisions kr_period_fact_revisions_source_measurement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_period_fact_revisions
    ADD CONSTRAINT kr_period_fact_revisions_source_measurement_id_fkey FOREIGN KEY (source_measurement_id) REFERENCES public.kr_measurements(id);


--
-- Name: kr_period_plan_revisions kr_period_plan_revisions_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_period_plan_revisions
    ADD CONSTRAINT kr_period_plan_revisions_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: kr_period_plan_revisions kr_period_plan_revisions_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_period_plan_revisions
    ADD CONSTRAINT kr_period_plan_revisions_period_id_fkey FOREIGN KEY (period_id) REFERENCES public.kr_periods(id);


--
-- Name: kr_period_plan_revisions kr_period_plan_revisions_previous_revision_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_period_plan_revisions
    ADD CONSTRAINT kr_period_plan_revisions_previous_revision_id_fkey FOREIGN KEY (previous_revision_id) REFERENCES public.kr_period_plan_revisions(id);


--
-- Name: kr_periods kr_periods_metric_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_periods
    ADD CONSTRAINT kr_periods_metric_id_fkey FOREIGN KEY (metric_id) REFERENCES public.kr_metrics(id);


--
-- Name: kr_reporting_statuses kr_reporting_statuses_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_reporting_statuses
    ADD CONSTRAINT kr_reporting_statuses_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: kr_reporting_statuses kr_reporting_statuses_meeting_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_reporting_statuses
    ADD CONSTRAINT kr_reporting_statuses_meeting_id_fkey FOREIGN KEY (meeting_id) REFERENCES public.reporting_meetings(id);


--
-- Name: kr_reporting_statuses kr_reporting_statuses_metric_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_reporting_statuses
    ADD CONSTRAINT kr_reporting_statuses_metric_id_fkey FOREIGN KEY (metric_id) REFERENCES public.kr_metrics(id);


--
-- Name: kr_reporting_statuses kr_reporting_statuses_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_reporting_statuses
    ADD CONSTRAINT kr_reporting_statuses_period_id_fkey FOREIGN KEY (period_id) REFERENCES public.kr_periods(id);


--
-- Name: kr_year_settings kr_year_settings_metric_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kr_year_settings
    ADD CONSTRAINT kr_year_settings_metric_id_fkey FOREIGN KEY (metric_id) REFERENCES public.kr_metrics(id);


--
-- Name: login_reservations login_reservations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_reservations
    ADD CONSTRAINT login_reservations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: major_external_links major_external_links_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.major_external_links
    ADD CONSTRAINT major_external_links_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: major_external_links major_external_links_major_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.major_external_links
    ADD CONSTRAINT major_external_links_major_task_id_fkey FOREIGN KEY (major_task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: meeting_actions meeting_actions_capture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_actions
    ADD CONSTRAINT meeting_actions_capture_id_fkey FOREIGN KEY (capture_id) REFERENCES public.meeting_captures(id);


--
-- Name: meeting_actions meeting_actions_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_actions
    ADD CONSTRAINT meeting_actions_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id);


--
-- Name: meeting_captures meeting_captures_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_captures
    ADD CONSTRAINT meeting_captures_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id);


--
-- Name: notifications notifications_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id);


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: notifications notifications_work_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_work_task_id_fkey FOREIGN KEY (work_task_id) REFERENCES public.work_tasks(id);


--
-- Name: project_tags project_tags_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_tags
    ADD CONSTRAINT project_tags_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: project_tags project_tags_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_tags
    ADD CONSTRAINT project_tags_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES public.tags(id);


--
-- Name: project_task_plans project_task_plans_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_plans
    ADD CONSTRAINT project_task_plans_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: projects projects_responsible_pl_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_responsible_pl_fkey FOREIGN KEY (responsible_pl) REFERENCES public.users(id);


--
-- Name: projects projects_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_status_id_fkey FOREIGN KEY (status_id) REFERENCES public.project_statuses(id);


--
-- Name: refresh_sessions refresh_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_sessions
    ADD CONSTRAINT refresh_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: reporting_meeting_history reporting_meeting_history_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporting_meeting_history
    ADD CONSTRAINT reporting_meeting_history_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.users(id);


--
-- Name: reporting_meeting_history reporting_meeting_history_meeting_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporting_meeting_history
    ADD CONSTRAINT reporting_meeting_history_meeting_id_fkey FOREIGN KEY (meeting_id) REFERENCES public.reporting_meetings(id);


--
-- Name: reporting_meetings reporting_meetings_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporting_meetings
    ADD CONSTRAINT reporting_meetings_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: reporting_meetings reporting_meetings_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporting_meetings
    ADD CONSTRAINT reporting_meetings_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: reports reports_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: request_work_links request_work_links_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_work_links
    ADD CONSTRAINT request_work_links_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: request_work_links request_work_links_major_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_work_links
    ADD CONSTRAINT request_work_links_major_task_id_fkey FOREIGN KEY (major_task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: request_work_links request_work_links_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_work_links
    ADD CONSTRAINT request_work_links_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.requirement_requests(id);


--
-- Name: request_work_links request_work_links_work_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.request_work_links
    ADD CONSTRAINT request_work_links_work_task_id_fkey FOREIGN KEY (work_task_id) REFERENCES public.work_tasks(id);


--
-- Name: requirement_requests requirement_requests_assignee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.requirement_requests
    ADD CONSTRAINT requirement_requests_assignee_id_fkey FOREIGN KEY (assignee_id) REFERENCES public.users(id);


--
-- Name: requirement_requests requirement_requests_coordinator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.requirement_requests
    ADD CONSTRAINT requirement_requests_coordinator_id_fkey FOREIGN KEY (coordinator_id) REFERENCES public.users(id);


--
-- Name: requirement_requests requirement_requests_reviewer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.requirement_requests
    ADD CONSTRAINT requirement_requests_reviewer_id_fkey FOREIGN KEY (reviewer_id) REFERENCES public.users(id);


--
-- Name: requirement_requests requirement_requests_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.requirement_requests
    ADD CONSTRAINT requirement_requests_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id);


--
-- Name: requirement_requests requirement_requests_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.requirement_requests
    ADD CONSTRAINT requirement_requests_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id);


--
-- Name: requirement_requests requirement_requests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.requirement_requests
    ADD CONSTRAINT requirement_requests_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: requirement_reviews requirement_reviews_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.requirement_reviews
    ADD CONSTRAINT requirement_reviews_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(id);


--
-- Name: requirement_reviews requirement_reviews_reviewer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.requirement_reviews
    ADD CONSTRAINT requirement_reviews_reviewer_id_fkey FOREIGN KEY (reviewer_id) REFERENCES public.users(id);


--
-- Name: requirement_reviews requirement_reviews_source_request_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.requirement_reviews
    ADD CONSTRAINT requirement_reviews_source_request_author_id_fkey FOREIGN KEY (source_request_author_id) REFERENCES public.users(id);


--
-- Name: requirement_reviews requirement_reviews_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.requirement_reviews
    ADD CONSTRAINT requirement_reviews_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id);


--
-- Name: security_events security_events_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_events
    ADD CONSTRAINT security_events_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id);


--
-- Name: security_events security_events_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_events
    ADD CONSTRAINT security_events_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.users(id);


--
-- Name: stories stories_epic_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stories
    ADD CONSTRAINT stories_epic_id_fkey FOREIGN KEY (epic_id) REFERENCES public.epics(id);


--
-- Name: tags tags_creator_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_creator_fkey FOREIGN KEY (creator) REFERENCES public.users(id);


--
-- Name: tags tags_lock_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_lock_owner_id_fkey FOREIGN KEY (lock_owner_id) REFERENCES public.users(id);


--
-- Name: task_attachments task_attachments_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_attachments
    ADD CONSTRAINT task_attachments_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id);


--
-- Name: task_attachments task_attachments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_attachments
    ADD CONSTRAINT task_attachments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: task_comments task_comments_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_comments
    ADD CONSTRAINT task_comments_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.task_comments(id);


--
-- Name: task_comments task_comments_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_comments
    ADD CONSTRAINT task_comments_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id);


--
-- Name: task_comments task_comments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_comments
    ADD CONSTRAINT task_comments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: task_history task_history_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_history
    ADD CONSTRAINT task_history_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.users(id);


--
-- Name: task_history task_history_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_history
    ADD CONSTRAINT task_history_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id);


--
-- Name: task_jira_links task_jira_links_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_jira_links
    ADD CONSTRAINT task_jira_links_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id);


--
-- Name: task_reporting_status_revisions task_reporting_status_revisions_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_reporting_status_revisions
    ADD CONSTRAINT task_reporting_status_revisions_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.users(id);


--
-- Name: task_reporting_status_revisions task_reporting_status_revisions_reporting_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_reporting_status_revisions
    ADD CONSTRAINT task_reporting_status_revisions_reporting_status_id_fkey FOREIGN KEY (reporting_status_id) REFERENCES public.task_reporting_statuses(id);


--
-- Name: task_reporting_statuses task_reporting_statuses_carried_from_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_reporting_statuses
    ADD CONSTRAINT task_reporting_statuses_carried_from_status_id_fkey FOREIGN KEY (carried_from_status_id) REFERENCES public.task_reporting_statuses(id);


--
-- Name: task_reporting_statuses task_reporting_statuses_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_reporting_statuses
    ADD CONSTRAINT task_reporting_statuses_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: task_reporting_statuses task_reporting_statuses_meeting_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_reporting_statuses
    ADD CONSTRAINT task_reporting_statuses_meeting_id_fkey FOREIGN KEY (meeting_id) REFERENCES public.reporting_meetings(id);


--
-- Name: task_reporting_statuses task_reporting_statuses_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_reporting_statuses
    ADD CONSTRAINT task_reporting_statuses_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id);


--
-- Name: task_reporting_statuses task_reporting_statuses_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_reporting_statuses
    ADD CONSTRAINT task_reporting_statuses_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: task_viewers task_viewers_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_viewers
    ADD CONSTRAINT task_viewers_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id);


--
-- Name: task_viewers task_viewers_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_viewers
    ADD CONSTRAINT task_viewers_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: tasks tasks_business_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_business_customer_id_fkey FOREIGN KEY (business_customer_id) REFERENCES public.business_customers(id);


--
-- Name: tasks tasks_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.channels(id);


--
-- Name: tasks tasks_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: tasks tasks_deadline_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_deadline_id_fkey FOREIGN KEY (deadline_id) REFERENCES public.deadlines(id);


--
-- Name: tasks tasks_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id);


--
-- Name: tasks tasks_lock_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_lock_owner_id_fkey FOREIGN KEY (lock_owner_id) REFERENCES public.users(id);


--
-- Name: tasks tasks_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id);


--
-- Name: tasks tasks_previous_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_previous_status_id_fkey FOREIGN KEY (previous_status_id) REFERENCES public.statuses(id);


--
-- Name: tasks tasks_priority_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_priority_id_fkey FOREIGN KEY (priority_id) REFERENCES public.priorities(id);


--
-- Name: tasks tasks_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: tasks tasks_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_status_id_fkey FOREIGN KEY (status_id) REFERENCES public.statuses(id);


--
-- Name: tasks tasks_task_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_task_type_id_fkey FOREIGN KEY (task_type_id) REFERENCES public.task_types(id);


--
-- Name: tasks tasks_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id);


--
-- Name: team_competency_resources team_competency_resources_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_competency_resources
    ADD CONSTRAINT team_competency_resources_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id);


--
-- Name: teams teams_team_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_team_type_id_fkey FOREIGN KEY (team_type_id) REFERENCES public.team_types(id);


--
-- Name: timeline_events timeline_events_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timeline_events
    ADD CONSTRAINT timeline_events_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(id);


--
-- Name: timeline_events timeline_events_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timeline_events
    ADD CONSTRAINT timeline_events_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: user_notification_preferences user_notification_preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_notification_preferences
    ADD CONSTRAINT user_notification_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_report_prefs user_report_prefs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_report_prefs
    ADD CONSTRAINT user_report_prefs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: users users_business_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_business_customer_id_fkey FOREIGN KEY (business_customer_id) REFERENCES public.business_customers(id);


--
-- Name: users users_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: users users_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id);


--
-- Name: work_attachments work_attachments_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_attachments
    ADD CONSTRAINT work_attachments_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: work_attachments work_attachments_work_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_attachments
    ADD CONSTRAINT work_attachments_work_task_id_fkey FOREIGN KEY (work_task_id) REFERENCES public.work_tasks(id);


--
-- Name: work_comments work_comments_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_comments
    ADD CONSTRAINT work_comments_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: work_comments work_comments_work_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_comments
    ADD CONSTRAINT work_comments_work_task_id_fkey FOREIGN KEY (work_task_id) REFERENCES public.work_tasks(id);


--
-- Name: work_dependencies work_dependencies_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_dependencies
    ADD CONSTRAINT work_dependencies_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: work_dependencies work_dependencies_source_major_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_dependencies
    ADD CONSTRAINT work_dependencies_source_major_id_fkey FOREIGN KEY (source_major_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: work_dependencies work_dependencies_source_work_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_dependencies
    ADD CONSTRAINT work_dependencies_source_work_id_fkey FOREIGN KEY (source_work_id) REFERENCES public.work_tasks(id);


--
-- Name: work_dependencies work_dependencies_target_major_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_dependencies
    ADD CONSTRAINT work_dependencies_target_major_id_fkey FOREIGN KEY (target_major_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: work_dependencies work_dependencies_target_work_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_dependencies
    ADD CONSTRAINT work_dependencies_target_work_id_fkey FOREIGN KEY (target_work_id) REFERENCES public.work_tasks(id);


--
-- Name: work_history work_history_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_history
    ADD CONSTRAINT work_history_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id);


--
-- Name: work_history work_history_work_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_history
    ADD CONSTRAINT work_history_work_task_id_fkey FOREIGN KEY (work_task_id) REFERENCES public.work_tasks(id);


--
-- Name: work_meeting_snapshots work_meeting_snapshots_meeting_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_meeting_snapshots
    ADD CONSTRAINT work_meeting_snapshots_meeting_id_fkey FOREIGN KEY (meeting_id) REFERENCES public.reporting_meetings(id);


--
-- Name: work_resolutions work_resolutions_decided_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_resolutions
    ADD CONSTRAINT work_resolutions_decided_by_fkey FOREIGN KEY (decided_by) REFERENCES public.users(id);


--
-- Name: work_resolutions work_resolutions_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_resolutions
    ADD CONSTRAINT work_resolutions_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.requirement_requests(id);


--
-- Name: work_task_templates work_task_templates_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_task_templates
    ADD CONSTRAINT work_task_templates_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id);


--
-- Name: work_tasks work_tasks_acceptor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_tasks
    ADD CONSTRAINT work_tasks_acceptor_id_fkey FOREIGN KEY (acceptor_id) REFERENCES public.users(id);


--
-- Name: work_tasks work_tasks_assignee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_tasks
    ADD CONSTRAINT work_tasks_assignee_id_fkey FOREIGN KEY (assignee_id) REFERENCES public.users(id);


--
-- Name: work_tasks work_tasks_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_tasks
    ADD CONSTRAINT work_tasks_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: work_tasks work_tasks_direct_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_tasks
    ADD CONSTRAINT work_tasks_direct_project_id_fkey FOREIGN KEY (direct_project_id) REFERENCES public.projects(id) ON DELETE SET NULL;


--
-- Name: work_tasks work_tasks_execution_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_tasks
    ADD CONSTRAINT work_tasks_execution_team_id_fkey FOREIGN KEY (execution_team_id) REFERENCES public.teams(id);


--
-- Name: work_tasks work_tasks_major_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_tasks
    ADD CONSTRAINT work_tasks_major_task_id_fkey FOREIGN KEY (major_task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: work_tasks work_tasks_requester_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_tasks
    ADD CONSTRAINT work_tasks_requester_id_fkey FOREIGN KEY (requester_id) REFERENCES public.users(id);


--
-- Name: work_tasks work_tasks_requester_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_tasks
    ADD CONSTRAINT work_tasks_requester_team_id_fkey FOREIGN KEY (requester_team_id) REFERENCES public.teams(id);


--
-- PostgreSQL database dump complete
--



INSERT INTO public.alembic_version(version_num) VALUES ('d453b20d51f9');
COMMIT;
