-- DBA ONLY: review, back up and apply outside the application.
BEGIN;
SET LOCAL lock_timeout='120s';
SELECT pg_advisory_xact_lock(709184521232);
DO $$ BEGIN IF (SELECT version_num FROM alembic_version) IS DISTINCT FROM 'd352a19c40e8' THEN RAISE EXCEPTION 'Unexpected database revision; DBA review required'; END IF; END $$;


-- Running upgrade d352a19c40e8 -> d453b20d51f9

ALTER TABLE tasks ALTER COLUMN team_id DROP NOT NULL;

UPDATE alembic_version SET version_num='d453b20d51f9' WHERE alembic_version.version_num = 'd352a19c40e8';

COMMIT;

