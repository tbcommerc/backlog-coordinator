Банковский core-выпуск. 23.11.2026.

Приложение работает только с уже подготовленной PostgreSQL 16. Структуру и
изменения применяет DBA отдельно. Startup и deploy-core.py не выполняют DDL,
не создают БД/DB-роли, не запускают Alembic и не заполняют пользователей или
справочники автоматически. Обычные прикладные операции сохраняют данные через DML.

1. DBA согласует backup/окно работ, создаёт БД и login-роль по правилам банка.
   Для пустой БД: проверить и применить dba/initial-schema.sql.
   Для существующей: SELECT version_num FROM public.alembic_version;
   Выбрать SQL только для реально записанной исходной ревизии. При неизвестной
   структуре или отсутствии версии не применять initial SQL поверх существующих
   данных и не выполнять stamp head. Требуется сопоставление схемы силами DBA.
   SQL содержит транзакцию и проверку исходной версии; повтор на другой версии
   останавливается. Проверенная схема — public.

2. DBA выдаёт runtime-роли DML-права. Шаблон dba/runtime-role-grants.sql
   использует psql-переменную app_role; он не создаёт роль и не задаёт пароль.
   Runtime-роль не владеет БД/таблицами, не имеет CREATE в рабочей схеме и
   записи в alembic_version. Учесть PUBLIC и наследуемые роли.

3. Образ приложения поставляется отдельно через разрешённый банком канал.
   Проверить точный image ID в release-manifest.json. На машине сборки:
   docker save dmb-backlog:bank-core-20261123-aa7f45f555db -o dmb-bank-image.tar
   В контуре: docker load --input dmb-bank-image.tar
   Заранее доставить также Redis/Nginx/Collector/ClamAV из Compose и актуальные
   базы ClamAV. До окна работ проверить docker image inspect для каждой ссылки
   image, включая закреплённые registry digests. Перенос TAR сам по себе не
   гарантирует разрешимость digest; внутренний registry/override согласует DevOps.

4. Заполнить защищённый env-файл вне Git по deploy/.env.production-core.example.
   DATABASE_URL указывает на готовую БД под runtime-ролью, с URL-encoded паролем
   и настройками TLS/CA по правилам банка. Секреты общие для реплик; AUTH_ORIGINS
   и CORS_ORIGINS — точные внешние HTTPS origins; AUTH_ALLOWED_HOSTS — имена
   внешнего хоста и внутренних health-check адресов. Доверенный ingress должен
   перезаписывать X-Forwarded-Proto и передавать Host/Authorization.

5. Из каталога deploy (Python 3.12 и Docker Compose):
   python scripts/deploy-core.py --env-file /secure/dmb-core.env --report-dir /secure/release-evidence
   Команда проверяет image ID, готовую схему и ограниченную роль до остановки
   приложения, затем запускает backend, ждёт readiness/ClamAV и открывает Nginx.
   SQL-файлы ей не передаются. Backup БД и обновление её структуры ведёт DBA.
   Старый полный compose.production.yaml с auto-migration не использовать.

6. Если БД пустая по данным, уполномоченный оператор отдельно создаёт первого
   администратора (это DML, не создание структуры):
   docker compose --env-file /secure/dmb-core.env -f compose.production-core.yaml run --rm --no-deps backend python account_operator.py bootstrap-admin --login DEMO_LOGIN --name "Администратор демонстрации" --reason BANK-TICKET --apply
   Подставить согласованные login/name/номер основания. Пароля по умолчанию нет:
   одноразовое приглашение передать через согласованный защищённый канал.
   Seed при старте нет; справочники наполняются отдельным согласованным действием.
   Для существующей БД сначала read-only отчёт:
   docker compose --env-file /secure/dmb-core.env -f compose.production-core.yaml run --rm --no-deps backend python account_operator.py reference-report
   Неоднозначные/несвязанные записи требуют просмотра. После отдельного
   согласования доступна команда reconcile-references --reason BANK-TICKET --apply
   вместо reference-report; это DML, автоматически она не выполняется.
   Для явно выбранного существующего администратора при необходимости:
   configure-admin-access --user-id ID --reason BANK-TICKET --apply
   Пароль сохраняется, старые сессии завершаются. Не запускать для других учёток.
   Затем проверить внешний банковский HTTPS адрес:
   python stand_smoke.py --base-url https://dmb.example.internal --login DEMO_LOGIN --expect-admin --wait-access-expiry --ca-file /secure/bank-ca.pem --output bank-smoke.json
   Пароль вводится скрыто. Не передавать пароль аргументом, не отключать TLS.
   Проверить браузером админку, справочники, создание только с названием,
   повторное чтение/изменение задачи, две вкладки, refresh и права наблюдателя.

SHA256SUMS.txt содержит SHA-256 всех файлов комплекта. reports — безопасные
локальные результаты, не приёмка банковской ВМ. Образ, банковские секреты,
временные сертификаты, runtime-env, тестовые реквизиты и backup БД в ZIP не входят.
